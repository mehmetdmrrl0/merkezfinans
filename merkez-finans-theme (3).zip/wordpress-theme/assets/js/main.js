/**
 * Merkez Finansal Danismanlik - Main JavaScript
 *
 * Pure Vanilla JS - No jQuery, no frameworks.
 * Handles: mobile menu, sticky header, scroll reveal, counter animation,
 * scroll progress, back-to-top, smooth scroll.
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

( function() {
	'use strict';

	// ============================================================
	// DOM Ready Helper
	// ============================================================

	function domReady( callback ) {
		if ( document.readyState === 'loading' ) {
			document.addEventListener( 'DOMContentLoaded', callback );
		} else {
			callback();
		}
	}

	// ============================================================
	// 1. MOBILE MENU (Hamburger)
	// ============================================================

	function initMobileMenu() {
		var toggle  = document.getElementById( 'mobile-menu-toggle' );
		var nav     = document.getElementById( 'mobile-navigation' );
		var navLinks;

		if ( ! toggle || ! nav ) {
			return;
		}

		navLinks = nav.querySelectorAll( '.nav-link' );

		/**
		 * Toggle menu open/closed state.
		 */
		function toggleMenu() {
			var isOpen = toggle.classList.contains( 'is-active' );

			if ( isOpen ) {
				closeMenu();
			} else {
				openMenu();
			}
		}

		/**
		 * Open mobile menu.
		 */
		function openMenu() {
			toggle.classList.add( 'is-active' );
			toggle.setAttribute( 'aria-expanded', 'true' );
			nav.hidden = false;
			// Small delay to allow display:block to apply before adding class
			requestAnimationFrame( function() {
				nav.classList.add( 'is-open' );
			});
			document.body.style.overflow = 'hidden';
		}

		/**
		 * Close mobile menu.
		 */
		function closeMenu() {
			toggle.classList.remove( 'is-active' );
			toggle.setAttribute( 'aria-expanded', 'false' );
			nav.classList.remove( 'is-open' );
			document.body.style.overflow = '';

			// Wait for transition to finish before hiding
			setTimeout( function() {
				if ( ! toggle.classList.contains( 'is-active' ) ) {
					nav.hidden = true;
				}
			}, 300 );
		}

		// Toggle click
		toggle.addEventListener( 'click', function( event ) {
			event.preventDefault();
			toggleMenu();
		});

		// Close on link click
		navLinks.forEach( function( link ) {
			link.addEventListener( 'click', function() {
				closeMenu();
			});
		});

		// Close on Escape key
		document.addEventListener( 'keydown', function( event ) {
			if ( event.key === 'Escape' && toggle.classList.contains( 'is-active' ) ) {
				closeMenu();
			}
		});

		// Close on click outside
		document.addEventListener( 'click', function( event ) {
			if (
				nav.classList.contains( 'is-open' ) &&
				! nav.contains( event.target ) &&
				! toggle.contains( event.target )
			) {
				closeMenu();
			}
		});
	}

	// ============================================================
	// 2. STICKY HEADER
	// ============================================================

	function initStickyHeader() {
		var header = document.getElementById( 'site-header' );
		var scrollThreshold = 50;

		if ( ! header ) {
			return;
		}

		/**
		 * Handle scroll for sticky header state.
		 */
		function handleScroll() {
			if ( window.scrollY > scrollThreshold ) {
				header.classList.add( 'is-scrolled' );
			} else {
				header.classList.remove( 'is-scrolled' );
			}
		}

		// Use requestAnimationFrame for smooth performance
		var ticking = false;

		window.addEventListener( 'scroll', function() {
			if ( ! ticking ) {
				window.requestAnimationFrame( function() {
					handleScroll();
					ticking = false;
				});
				ticking = true;
			}
		});

		// Initial check
		handleScroll();
	}

	// ============================================================
	// 3. SCROLL REVEAL ANIMATIONS (Intersection Observer)
	// ============================================================

	function initScrollReveal() {
		var revealElements = document.querySelectorAll( '.reveal' );

		if ( ! revealElements.length ) {
			return;
		}

		// Check if user prefers reduced motion
		var prefersReducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

		if ( prefersReducedMotion ) {
			revealElements.forEach( function( el ) {
				el.classList.add( 'revealed' );
			});
			return;
		}

		var observerOptions = {
			root: null,
			rootMargin: '0px 0px -50px 0px',
			threshold: 0.1,
		};

		var revealObserver = new IntersectionObserver( function( entries ) {
			entries.forEach( function( entry ) {
				if ( entry.isIntersecting ) {
					entry.target.classList.add( 'revealed' );
					revealObserver.unobserve( entry.target );
				}
			});
		}, observerOptions );

		revealElements.forEach( function( el ) {
			revealObserver.observe( el );
		});
	}

	// ============================================================
	// 4. COUNTER ANIMATION (Intersection Observer)
	// ============================================================

	function initCounterAnimation() {
		var counters = document.querySelectorAll( '.stat-number[data-target]' );

		if ( ! counters.length ) {
			return;
		}

		var prefersReducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

		var counterObserver = new IntersectionObserver( function( entries ) {
			entries.forEach( function( entry ) {
				if ( entry.isIntersecting ) {
					animateCounter( entry.target, prefersReducedMotion );
					counterObserver.unobserve( entry.target );
				}
			});
		}, { threshold: 0.5 });

		counters.forEach( function( counter ) {
			counterObserver.observe( counter );
		});
	}

	/**
	 * Animate a counter element from 0 to target.
	 *
	 * @param {HTMLElement} element - The counter element.
	 * @param {boolean}     instant - If true, set immediately (reduced motion).
	 */
	function animateCounter( element, instant ) {
		var target    = parseInt( element.getAttribute( 'data-target' ), 10 );
		var duration  = instant ? 0 : 2000;
		var startTime = null;

		if ( instant ) {
			element.textContent = target;
			return;
		}

		/**
		 * Easing function (ease-out cubic).
		 *
		 * @param {number} t - Progress (0 to 1).
		 * @return {number}
		 */
		function easeOutCubic( t ) {
			return 1 - Math.pow( 1 - t, 3 );
		}

		/**
		 * Update the counter value.
		 *
		 * @param {number} timestamp - Current animation frame timestamp.
		 */
		function updateCounter( timestamp ) {
			if ( ! startTime ) {
				startTime = timestamp;
			}

			var elapsed = timestamp - startTime;
			var progress = Math.min( elapsed / duration, 1 );
			var easedProgress = easeOutCubic( progress );
			var currentValue = Math.floor( easedProgress * target );

			element.textContent = currentValue;

			if ( progress < 1 ) {
				requestAnimationFrame( updateCounter );
			} else {
				element.textContent = target;
			}
		}

		requestAnimationFrame( updateCounter );
	}

	// ============================================================
	// 5. SCROLL PROGRESS BAR
	// ============================================================

	function initScrollProgress() {
		var progressBar = document.getElementById( 'scroll-progress' );

		if ( ! progressBar ) {
			return;
		}

		var ticking = false;

		/**
		 * Update scroll progress bar width.
		 */
		function updateProgress() {
			var scrollTop    = window.scrollY || document.documentElement.scrollTop;
			var scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;

			if ( scrollHeight <= 0 ) {
				return;
			}

			var progress = ( scrollTop / scrollHeight ) * 100;

			progressBar.style.width = progress + '%';
			progressBar.setAttribute( 'aria-valuenow', Math.round( progress ) );
		}

		window.addEventListener( 'scroll', function() {
			if ( ! ticking ) {
				window.requestAnimationFrame( function() {
					updateProgress();
					ticking = false;
				});
				ticking = true;
			}
		});

		// Initial update
		updateProgress();
	}

	// ============================================================
	// 6. BACK TO TOP BUTTON
	// ============================================================

	function initBackToTop() {
		var button = document.getElementById( 'back-to-top' );

		if ( ! button ) {
			return;
		}

		var showThreshold = 400;
		var ticking = false;

		/**
		 * Toggle button visibility based on scroll position.
		 */
		function toggleVisibility() {
			if ( window.scrollY > showThreshold ) {
				button.classList.add( 'is-visible' );
				button.hidden = false;
			} else {
				button.classList.remove( 'is-visible' );
			}
		}

		window.addEventListener( 'scroll', function() {
			if ( ! ticking ) {
				window.requestAnimationFrame( function() {
					toggleVisibility();
					ticking = false;
				});
				ticking = true;
			}
		});

		button.addEventListener( 'click', function( event ) {
			event.preventDefault();
			window.scrollTo({
				top: 0,
				behavior: 'smooth',
			});
		});

		// Initial check
		toggleVisibility();
	}

	// ============================================================
	// 7. SMOOTH SCROLL (Anchor Links)
	// ============================================================

	function initSmoothScroll() {
		/**
		 * Handle anchor link clicks.
		 *
		 * @param {Event} event - Click event.
		 */
		function handleAnchorClick( event ) {
			var anchor = event.currentTarget;
			var href   = anchor.getAttribute( 'href' );

			// Only handle same-page anchor links
			if ( ! href || href.charAt( 0 ) !== '#' || href.length < 2 ) {
				return;
			}

			var target = document.querySelector( href );

			if ( ! target ) {
				return;
			}

			event.preventDefault();

			var headerOffset = 80;
			var elementPosition = target.getBoundingClientRect().top;
			var offsetPosition = elementPosition + window.scrollY - headerOffset;

			window.scrollTo({
				top: offsetPosition,
				behavior: 'smooth',
			});

			// Update focus for accessibility
			target.setAttribute( 'tabindex', '-1' );
			target.focus({ preventScroll: true });
		}

		// Attach to all anchor links
		var anchorLinks = document.querySelectorAll( 'a[href^="#"]' );

		anchorLinks.forEach( function( link ) {
			link.addEventListener( 'click', handleAnchorClick );
		});
	}

	// ============================================================
	// 8. ACTIVE NAV LINK (Highlight current section)
	// ============================================================

	function initActiveNavLink() {
		var sections = document.querySelectorAll( 'section[id]' );
		var navLinks = document.querySelectorAll( '.nav-link[href^="#"]' );

		if ( ! sections.length || ! navLinks.length ) {
			return;
		}

		var ticking = false;

		/**
		 * Update active nav link based on scroll position.
		 */
		function updateActiveLink() {
			var scrollPos = window.scrollY + 150;

			sections.forEach( function( section ) {
				var top    = section.offsetTop;
				var height = section.offsetHeight;
				var id     = section.getAttribute( 'id' );

				if ( scrollPos >= top && scrollPos < top + height ) {
					navLinks.forEach( function( link ) {
						link.classList.remove( 'is-active' );
						if ( link.getAttribute( 'href' ) === '#' + id ) {
							link.classList.add( 'is-active' );
						}
					});
				}
			});
		}

		window.addEventListener( 'scroll', function() {
			if ( ! ticking ) {
				window.requestAnimationFrame( function() {
					updateActiveLink();
					ticking = false;
				});
				ticking = true;
			}
		});
	}

	// ============================================================
	// 9. FORM VALIDATION ENHANCEMENTS
	// ============================================================

	function initFormValidation() {
		var forms = document.querySelectorAll( '.contact-form' );

		forms.forEach( function( form ) {
			form.addEventListener( 'submit', function( event ) {
				var requiredFields = form.querySelectorAll( '[required]' );
				var isValid = true;

				requiredFields.forEach( function( field ) {
					if ( ! field.value.trim() ) {
						isValid = false;
						field.style.borderColor = '#ef4444';
					} else {
						field.style.borderColor = '';
					}
				});

				// KVKK checkbox
				var kvkkCheckbox = form.querySelector( '[name="contact_kvkk"]' );
				if ( kvkkCheckbox && ! kvkkCheckbox.checked ) {
					isValid = false;
					kvkkCheckbox.parentElement.style.color = '#ef4444';
				}

				if ( ! isValid ) {
					event.preventDefault();
				}
			});

			// Clear error styles on input
			var inputs = form.querySelectorAll( 'input, textarea, select' );
			inputs.forEach( function( input ) {
				input.addEventListener( 'input', function() {
					input.style.borderColor = '';
				});
			});
		});
	}

	// ============================================================
	// 10. LAZY LOAD IMAGES (Native)
	// ============================================================

	function initLazyLoad() {
		var lazyImages = document.querySelectorAll( 'img[loading="lazy"]' );

		if ( ! lazyImages.length || 'loading' in HTMLImageElement.prototype ) {
			return;
		}

		// Fallback for browsers that don't support native lazy loading
		var imageObserver = new IntersectionObserver( function( entries ) {
			entries.forEach( function( entry ) {
				if ( entry.isIntersecting ) {
					var img = entry.target;
					img.src = img.dataset.src || img.src;
					img.removeAttribute( 'loading' );
					imageObserver.unobserve( img );
				}
			});
		});

		lazyImages.forEach( function( img ) {
			imageObserver.observe( img );
		});
	}

	// ============================================================
	// 10. NEWSLETTER AJAX SUBMIT
	// ============================================================

	function initNewsletterForm() {
		var form = document.getElementById( 'newsletter-form' );
		if ( ! form ) {
			return;
		}

		form.addEventListener( 'submit', function( event ) {
			event.preventDefault();

			var emailInput = document.getElementById( 'subscriber-email' );
			var messageDiv = document.getElementById( 'newsletter-message' );
			var nonceField = form.querySelector( 'input[name="newsletter_nonce"]' );
			var email = emailInput ? emailInput.value.trim() : '';
			var nonce = nonceField ? nonceField.value : '';

			if ( ! email ) {
				showMessage( 'Lutfen gecerli bir e-posta adresi girin.', 'error' );
				return;
			}

			var formData = new FormData();
			formData.append( 'action', 'merkez_finans_subscribe' );
			formData.append( 'subscriber_email', email );
			formData.append( 'nonce', nonce );

			fetch( merkezFinans.ajaxUrl, {
				method: 'POST',
				body: formData,
				credentials: 'same-origin',
			} )
				.then( function( response ) {
					return response.json();
				} )
				.then( function( data ) {
					if ( data.success ) {
						showMessage( 'Aboneliğiniz basariyla alinmistir. Tesekkur ederiz!', 'success' );
						emailInput.value = '';
					} else {
						showMessage( data.data && data.data.message ? data.data.message : 'Bir hata olustu. Lutfen tekrar deneyin.', 'error' );
					}
				} )
				.catch( function() {
					showMessage( 'Baglanti hatasi. Lutfen tekrar deneyin.', 'error' );
				} );

			function showMessage( text, type ) {
				if ( ! messageDiv ) {
					return;
				}
				messageDiv.textContent = text;
				messageDiv.style.display = 'block';
				messageDiv.className = 'newsletter-message is-' + type;
				setTimeout( function() {
					messageDiv.style.display = 'none';
				}, 5000 );
			}
		} );
	}

	// ============================================================
	// INITIALIZATION
	// ============================================================

	domReady( function() {
		initMobileMenu();
		initStickyHeader();
		initScrollReveal();
		initCounterAnimation();
		initScrollProgress();
		initBackToTop();
		initSmoothScroll();
		initActiveNavLink();
		initFormValidation();
		initLazyLoad();
		initNewsletterForm();
	});

})();
