/**
 * Gutenberg Block Editor JavaScript
 *
 * Adds custom block styles and enhancements to the editor.
 *
 * @package Merkez_Finans
 */

( function( wp ) {
	'use strict';

	if ( ! wp || ! wp.blocks ) {
		return;
	}

	// Register custom block styles
	wp.blocks.registerBlockStyle( 'core/button', {
		name: 'arrow',
		label: 'Ok İkonlu',
	});

	wp.blocks.registerBlockStyle( 'core/heading', {
		name: 'gradient',
		label: 'Gradient Başlık',
	});

	wp.blocks.registerBlockStyle( 'core/paragraph', {
		name: 'lead',
		label: 'Öne Çıkan Metin',
	});

	wp.blocks.registerBlockStyle( 'core/group', {
		name: 'card',
		label: 'Kart',
	});

})( window.wp );
