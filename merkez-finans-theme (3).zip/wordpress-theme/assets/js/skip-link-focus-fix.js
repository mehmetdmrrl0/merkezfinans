/**
 * Skip Link Focus Fix
 *
 * Helps with accessibility for "Skip to content" links.
 * Ensures focus moves correctly when using skip links.
 *
 * @package Merkez_Finans
 */

( function() {
	'use strict';

	var isIe = navigator.userAgent.toLowerCase().indexOf( 'msie' ) !== -1 ||
		       navigator.userAgent.toLowerCase().indexOf( 'trident' ) !== -1;

	if ( ! isIe || ! document.getElementById || ! window.addEventListener ) {
		return;
	}

	/**
	 * Fix tabindex for non-focusable elements.
	 */
	function fixTabindex() {
		var id = window.location.hash.substring( 1 );
		var element;

		if ( ! ( /^[A-z0-9_-]+$/.test( id ) ) ) {
			return;
		}

		element = document.getElementById( id );

		if ( element ) {
			if ( ! /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) ) {
				element.tabIndex = -1;
			}

			element.focus();
		}
	}

	window.addEventListener( 'hashchange', fixTabindex );

	// Fix on page load if there's a hash
	if ( window.location.hash ) {
		fixTabindex();
	}
})();
