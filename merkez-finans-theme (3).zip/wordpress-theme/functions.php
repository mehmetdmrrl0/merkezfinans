<?php
/**
 * Merkez Finansal Danismanlik Theme Functions
 *
 * @package Merkez_Finans
 * @version 1.0.0
 * @author Merkez Finansal Danismanlik
 * @link https://merkezfinans.com
 */

declare( strict_types=1 );

// ============================================================
// 0. TEMA SABITLERI
// ============================================================

if ( ! defined( 'MERKEZ_FINANS_VERSION' ) ) {
	define( 'MERKEZ_FINANS_VERSION', '1.0.0' );
}

if ( ! defined( 'MERKEZ_FINANS_DIR' ) ) {
	define( 'MERKEZ_FINANS_DIR', get_template_directory() );
}

if ( ! defined( 'MERKEZ_FINANS_URI' ) ) {
	define( 'MERKEZ_FINANS_URI', get_template_directory_uri() );
}

// ============================================================
// 0.5 REQUIRED FILES
// ============================================================

require_once MERKEZ_FINANS_DIR . '/inc/class-merkez-finans-nav-walker.php';

// ============================================================
// 1. TEMA KURULUMU & TEMA DESTEKLERI
// ============================================================

if ( ! function_exists( 'merkez_finans_setup' ) ) :
	/**
	 * Tema kurulumu ve WordPress cekirdek desteklerini etkinlestir.
	 *
	 * @return void
	 */
	function merkez_finans_setup(): void {

		// Dil cevirileri yolu
		load_theme_textdomain( 'merkez-finans', MERKEZ_FINANS_DIR . '/languages' );

		// 1.1. Otomatik feed linkleri (RSS)
		add_theme_support( 'automatic-feed-links' );

		// 1.2. Title tag yonetimi
		add_theme_support( 'title-tag' );

		// 1.3. Post thumbnail (ozel gorseller)
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 1200, 9999 );

		// 1.4. HTML5 destegi
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'script',
				'style',
			)
		);

		// 1.5. Responsive gomulu icerik (video, iframe vb.)
		add_theme_support( 'responsive-embeds' );

		// 1.6. Gutenberg block editor stilleri (editor-style.css)
		add_theme_support( 'editor-styles' );
		add_editor_style( 'editor-style.css' );

		// 1.7. Genis/hizali Gutenberg block'lari
		add_theme_support( 'align-wide' );
	
		// 1.8. WooCommerce destegi (gelecekte kullanilabilir)
		// add_theme_support( 'woocommerce' );

		// 1.9. Custom Logo destegi
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 80,
				'width'       => 300,
				'flex-height' => true,
				'flex-width'  => true,
			)
		);

		// 1.10. Custom Header (opsiyonel)
		add_theme_support(
			'custom-header',
			array(
				'width'              => 1920,
				'height'             => 600,
				'flex-height'        => true,
				'flex-width'         => true,
				'uploads'            => true,
				'video'              => true,
				'video-active-callback' => 'is_front_page',
			)
		);

		// 1.11. Block styles destegi
		add_theme_support( 'wp-block-styles' );

		// 1.12. Appearance tools (spacing, border, link color vb.)
		add_theme_support( 'appearance-tools' );

		// 1.13. Link color kontrolu
		add_theme_support( 'link-color' );

		// 1.14. Custom units
		add_theme_support( 'custom-units', 'px', 'rem', 'em', 'vh', 'vw', '%' );

		// 1.15. Custom line height
		add_theme_support( 'custom-line-height' );

		// 1.16. Custom spacing
		add_theme_support( 'custom-spacing' );

		// 1.17. Border support
		add_theme_support( 'border' );

		// 1.18. Jetpack destegi
		add_theme_support( 'jetpack-content-options', array(
			'blog-display'    => 'content',
			'author-bio'      => true,
			'author-bio-default' => false,
		) );

	}
endif;
add_action( 'after_setup_theme', 'merkez_finans_setup' );

// ============================================================
// 2. MENUMENU ALANLARI (NAV MENUS)
// ============================================================

if ( ! function_exists( 'merkez_finans_menus' ) ) :
	/**
	 * Tema menu alanlarini kaydet.
	 *
	 * @return void
	 */
	function merkez_finans_menus(): void {
		register_nav_menus(
			array(
				'primary'     => __( 'Ana Menu (Header)', 'merkez-finans' ),
				'footer-left' => __( 'Footer Menu - Sol', 'merkez-finans' ),
				'footer-right'=> __( 'Footer Menu - Sag', 'merkez-finans' ),
			)
		);
	}
endif;
add_action( 'init', 'merkez_finans_menus' );

// ============================================================
// 3. WIDGET ALANLARI (SIDEBAR & FOOTER)
// ============================================================

if ( ! function_exists( 'merkez_finans_widgets' ) ) :
	/**
	 * Tema widget alanlarini kaydet.
	 *
	 * @return void
	 */
	function merkez_finans_widgets(): void {

		// Sidebar (Blog sayfalari icin)
		register_sidebar(
			array(
				'name'          => __( 'Sidebar', 'merkez-finans' ),
				'id'            => 'sidebar-1',
				'description'   => __( 'Blog ve arsiv sayfalarinda yan panel.', 'merkez-finans' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h4 class="widget-title">',
				'after_title'   => '</h4>',
			)
		);

		// Footer - 1. Sutun
		register_sidebar(
			array(
				'name'          => __( 'Footer - 1. Sutun', 'merkez-finans' ),
				'id'            => 'footer-1',
				'description'   => __( 'Footer alaninin 1. sutunu.', 'merkez-finans' ),
				'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h5 class="footer-widget-title">',
				'after_title'   => '</h5>',
			)
		);

		// Footer - 2. Sutun
		register_sidebar(
			array(
				'name'          => __( 'Footer - 2. Sutun', 'merkez-finans' ),
				'id'            => 'footer-2',
				'description'   => __( 'Footer alaninin 2. sutunu.', 'merkez-finans' ),
				'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h5 class="footer-widget-title">',
				'after_title'   => '</h5>',
			)
		);

		// Footer - 3. Sutun
		register_sidebar(
			array(
				'name'          => __( 'Footer - 3. Sutun', 'merkez-finans' ),
				'id'            => 'footer-3',
				'description'   => __( 'Footer alaninin 3. sutunu.', 'merkez-finans' ),
				'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h5 class="footer-widget-title">',
				'after_title'   => '</h5>',
			)
		);

	}
endif;
add_action( 'widgets_init', 'merkez_finans_widgets' );

// ============================================================
// 4. STIL VE SCRIPT YUKLEMELERI
// ============================================================

if ( ! function_exists( 'merkez_finans_scripts' ) ) :
	/**
	 * Tema stil ve script dosyalarini yukle.
	 *
	 * @return void
	 */
	function merkez_finans_scripts(): void {

		// 4.1. Google Fonts (Manrope + Inter)
		wp_enqueue_style(
			'merkez-finans-fonts',
			'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap',
			array(),
			null
		);

		// 4.2. Ana tema stili
		wp_enqueue_style(
			'merkez-finans-style',
			get_stylesheet_uri(),
			array(),
			MERKEZ_FINANS_VERSION
		);

		// 4.3. Tema ana CSS (layout, bilesenler, responsive)
		wp_enqueue_style(
			'merkez-finans-main',
			MERKEZ_FINANS_URI . '/assets/css/main.css',
			array(),
			MERKEZ_FINANS_VERSION
		);

		// 4.4. Blok editor stilleri (Gutenberg frontend uyumu)
		wp_enqueue_style(
			'merkez-finans-blocks',
			MERKEZ_FINANS_URI . '/assets/css/blocks.css',
			array(),
			MERKEZ_FINANS_VERSION
		);

		// 4.5. Vanilla JS - Ana tema javascripti
		wp_enqueue_script(
			'merkez-finans-main',
			MERKEZ_FINANS_URI . '/assets/js/main.js',
			array(),
			MERKEZ_FINANS_VERSION,
			true
		);

		// 4.6. Skip-link focus fix (erisilebilirlik)
		wp_enqueue_script(
			'merkez-finans-skip-link-focus-fix',
			MERKEZ_FINANS_URI . '/assets/js/skip-link-focus-fix.js',
			array(),
			MERKEZ_FINANS_VERSION,
			true
		);

		// 4.7. yorum reply script (sadece yorum acik sayfalarda)
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		// 4.8. Script'e AJAX URL ve nonce gecir (guvenlik)
		wp_localize_script(
			'merkez-finans-main',
			'merkezFinans',
			array(
				'ajaxUrl' => esc_url( admin_url( 'admin-ajax.php' ) ),
				'nonce'   => wp_create_nonce( 'merkez_finans_nonce' ),
				'themeUri'=> esc_url( MERKEZ_FINANS_URI ),
			)
		);

	}
endif;
add_action( 'wp_enqueue_scripts', 'merkez_finans_scripts' );

// ============================================================
// 5. ADMIN / BACKEND STILLERI
// ============================================================

if ( ! function_exists( 'merkez_finans_admin_scripts' ) ) :
	/**
	 * Admin panel stil ve scriptlerini yukle.
	 *
	 * @return void
	 */
	function merkez_finans_admin_scripts(): void {
		wp_enqueue_style(
			'merkez-finans-admin',
			MERKEZ_FINANS_URI . '/assets/css/admin.css',
			array(),
			MERKEZ_FINANS_VERSION
		);
	}
endif;
add_action( 'admin_enqueue_scripts', 'merkez_finans_admin_scripts' );

// ============================================================
// 6. LOGIN PAGE STILLERI
// ============================================================

if ( ! function_exists( 'merkez_finans_login_styles' ) ) :
	/**
	 * WordPress giris sayfasi stillerini ozellestir.
	 *
	 * @return void
	 */
	function merkez_finans_login_styles(): void {
		wp_enqueue_style(
			'merkez-finans-login',
			MERKEZ_FINANS_URI . '/assets/css/login.css',
			array(),
			MERKEZ_FINANS_VERSION
		);
	}
endif;
add_action( 'login_enqueue_scripts', 'merkez_finans_login_styles' );

// ============================================================
// 7. CUSTOMIZER - TEMA AYARLARI
// ============================================================

if ( ! function_exists( 'merkez_finans_customize_register' ) ) :
	/**
	 * WordPress Customizer alanlarini ekle.
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer nesnesi.
	 * @return void
	 */
	function merkez_finans_customize_register( WP_Customize_Manager $wp_customize ): void {

		// 7.1. Tema Ayarlari Paneli
		$wp_customize->add_panel(
			'merkez_finans_panel',
			array(
				'title'       => __( 'Merkez Finans Ayarlari', 'merkez-finans' ),
				'description' => __( 'Tema renkleri, iletisim bilgileri ve diger ayarlar.', 'merkez-finans' ),
				'priority'    => 30,
			)
		);

		// --- Renk Ayarlari Bolumu ---
		$wp_customize->add_section(
			'merkez_finans_colors',
			array(
				'title'    => __( 'Tema Renkleri', 'merkez-finans' ),
				'panel'    => 'merkez_finans_panel',
				'priority' => 10,
			)
		);

		// Primary Renk
		$wp_customize->add_setting(
			'merkez_finans_primary_color',
			array(
				'default'           => '#071B3A',
				'sanitize_callback' => 'sanitize_hex_color',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				'merkez_finans_primary_color',
				array(
					'label'   => __( 'Ana Renk (Navy)', 'merkez-finans' ),
					'section' => 'merkez_finans_colors',
				)
			)
		);

		// Accent Renk
		$wp_customize->add_setting(
			'merkez_finans_accent_color',
			array(
				'default'           => '#2EA8FF',
				'sanitize_callback' => 'sanitize_hex_color',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				'merkez_finans_accent_color',
				array(
					'label'   => __( 'Vurgu Renk (Accent)', 'merkez-finans' ),
					'section' => 'merkez_finans_colors',
				)
			)
		);

		// --- Iletisim Bilgileri Bolumu ---
		$wp_customize->add_section(
			'merkez_finans_contact',
			array(
				'title'    => __( 'Iletisim Bilgileri', 'merkez-finans' ),
				'panel'    => 'merkez_finans_panel',
				'priority' => 20,
			)
		);

		// Telefon
		$wp_customize->add_setting(
			'merkez_finans_phone',
			array(
				'default'           => '0212 123 45 67',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_phone',
			array(
				'label'   => __( 'Telefon', 'merkez-finans' ),
				'section' => 'merkez_finans_contact',
				'type'    => 'text',
			)
		);

		// E-posta
		$wp_customize->add_setting(
			'merkez_finans_email',
			array(
				'default'           => 'info@merkezfinans.com',
				'sanitize_callback' => 'sanitize_email',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_email',
			array(
				'label'   => __( 'E-posta', 'merkez-finans' ),
				'section' => 'merkez_finans_contact',
				'type'    => 'email',
			)
		);

		// Adres
		$wp_customize->add_setting(
			'merkez_finans_address',
			array(
				'default'           => "Levent Mah. Finans Cad. No:42\nBesiktas/Istanbul",
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_address',
			array(
				'label'   => __( 'Adres', 'merkez-finans' ),
				'section' => 'merkez_finans_contact',
				'type'    => 'textarea',
			)
		);

		// Calisma Saatleri
		$wp_customize->add_setting(
			'merkez_finans_working_hours',
			array(
				'default'           => 'Pazartesi - Cuma: 09:00 - 18:00',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_working_hours',
			array(
				'label'   => __( 'Calisma Saatleri', 'merkez-finans' ),
				'section' => 'merkez_finans_contact',
				'type'    => 'text',
			)
		);

		// WhatsApp Numarasi
		$wp_customize->add_setting(
			'merkez_finans_whatsapp',
			array(
				'default'           => '902121234567',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_whatsapp',
			array(
				'label'       => __( 'WhatsApp Numarasi', 'merkez-finans' ),
				'description' => __( 'Uluslararasi formatta, + olmadan. Ornek: 902121234567', 'merkez-finans' ),
				'section'     => 'merkez_finans_contact',
				'type'        => 'text',
			)
		);

		// --- SEO & Sosyal Medya Bolumu ---
		$wp_customize->add_section(
			'merkez_finans_social',
			array(
				'title'    => __( 'Sosyal Medya', 'merkez-finans' ),
				'panel'    => 'merkez_finans_panel',
				'priority' => 30,
			)
		);

		$social_networks = array(
			'linkedin'  => __( 'LinkedIn', 'merkez-finans' ),
			'twitter'   => __( 'Twitter / X', 'merkez-finans' ),
			'facebook'  => __( 'Facebook', 'merkez-finans' ),
			'instagram' => __( 'Instagram', 'merkez-finans' ),
			'youtube'   => __( 'YouTube', 'merkez-finans' ),
		);

		foreach ( $social_networks as $slug => $label ) {
			$wp_customize->add_setting(
				"merkez_finans_social_{$slug}",
				array(
					'default'           => '',
					'sanitize_callback' => 'esc_url_raw',
					'transport'         => 'refresh',
				)
			);
			$wp_customize->add_control(
				"merkez_finans_social_{$slug}",
				array(
					'label'   => $label,
					'section' => 'merkez_finans_social',
					'type'    => 'url',
				)
			);
		}

		// --- Anasayfa Blog Bolumu ---
		$wp_customize->add_section(
			'merkez_finans_frontpage_blog',
			array(
				'title'       => __( 'Anasayfa Blog Ayarlari', 'merkez-finans' ),
				'panel'       => 'merkez_finans_panel',
				'priority'    => 51,
				'description' => __( 'Anasayfada hangi blog yazilarinin gorunecegini ve blog sayfasi ayarlarini buradan duzenleyebilirsiniz.', 'merkez-finans' ),
			)
		);

		// Blog bolumu basligi
		$wp_customize->add_setting(
			'merkez_finans_blog_badge',
			array(
				'default'           => 'Blog & Bilgilendirme',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_badge',
			array(
				'label'       => __( 'Blog Rozet (Badge) Metni', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_blog',
				'type'        => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_blog_title',
			array(
				'default'           => 'Guncel',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_title',
			array(
				'label'       => __( 'Blog Baslik - 1. Kisim', 'merkez-finans' ),
				'description' => __( 'Renkli kisim', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_blog',
				'type'        => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_blog_title_gradient',
			array(
				'default'           => 'Bilgiler',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_title_gradient',
			array(
				'label'       => __( 'Blog Baslik - 2. Kisim (Renkli)', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_blog',
				'type'        => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_blog_title_suffix',
			array(
				'default'           => 've Rehberler',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_title_suffix',
			array(
				'label'       => __( 'Blog Baslik - 3. Kisim', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_blog',
				'type'        => 'text',
			)
		);

		// Blog gosterim modu: Otomatik / Manuel
		$wp_customize->add_setting(
			'merkez_finans_blog_display_mode',
			array(
				'default'           => 'auto',
				'sanitize_callback' => function( $value ) {
					return in_array( $value, array( 'auto', 'manual' ), true ) ? $value : 'auto';
				},
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_display_mode',
			array(
				'label'       => __( 'Yazi Gosterim Modu', 'merkez-finans' ),
				'description' => __( '"Otomatik" en son yazilari gosterir. "Manuel" secilen ozel yazilari gosterir.', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_blog',
				'type'        => 'select',
				'choices'     => array(
					'auto'   => __( 'Otomatik (Son yazilar)', 'merkez-finans' ),
					'manual' => __( 'Manuel (Ozel secim)', 'merkez-finans' ),
				),
			)
		);

		// Otomatik modda kac yazı gosterilecek
		$wp_customize->add_setting(
			'merkez_finans_blog_post_count',
			array(
				'default'           => 3,
				'sanitize_callback' => 'absint',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_post_count',
			array(
				'label'       => __( 'Gosterilecek Yazi Sayisi', 'merkez-finans' ),
				'description' => __( 'Otomatik modda anasayfada kac yazi gorunecek?', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_blog',
				'type'        => 'number',
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 12,
					'step' => 1,
				),
			)
		);

		// Manuel modda yazı ID'leri (virgulle ayrilmis)
		$wp_customize->add_setting(
			'merkez_finans_blog_manual_posts',
			array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_manual_posts',
			array(
				'label'       => __( 'Manuel Yazi ID\'leri', 'merkez-finans' ),
				'description' => __( 'Manuel mod icin virgulle ayrilmis yazi ID\'leri. Ornek: 12,45,78. Bos birakirsan son yazilar gosterilir.', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_blog',
				'type'        => 'text',
			)
		);

		// Blog sayfasi basligi
		$wp_customize->add_setting(
			'merkez_finans_blog_page_title',
			array(
				'default'           => 'Blog & Bilgilendirme',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_page_title',
			array(
				'label'       => __( 'Blog Sayfasi Basligi', 'merkez-finans' ),
				'description' => __( 'Blog listeleme sayfasinin basligi.', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_blog',
				'type'        => 'text',
			)
		);

		// Blog sayfasi alt baslik
		$wp_customize->add_setting(
			'merkez_finans_blog_page_subtitle',
			array(
				'default'           => 'Finansal danismanlik, vergi mevzuati ve is dunyasindan guncel icerikler.',
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_blog_page_subtitle',
			array(
				'label'   => __( 'Blog Sayfasi Alt Basligi', 'merkez-finans' ),
				'section' => 'merkez_finans_frontpage_blog',
				'type'    => 'textarea',
			)
		);

		// --- Anasayfa Hizmet Ayarlari ---
		$wp_customize->add_section(
			'merkez_finans_frontpage_services',
			array(
				'title'       => __( 'Anasayfa Hizmet Ayarlari', 'merkez-finans' ),
				'panel'       => 'merkez_finans_panel',
				'priority'    => 50,
				'description' => __( 'Anasayfada hangi hizmetlerin gorunecegini ve hizmet sayfasi ayarlarini buradan duzenleyebilirsiniz.', 'merkez-finans' ),
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_badge',
			array(
				'default'           => 'Hizmetlerimiz',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_badge',
			array(
				'label'   => __( 'Hizmetler Rozet (Badge) Metni', 'merkez-finans' ),
				'section' => 'merkez_finans_frontpage_services',
				'type'    => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_title_1',
			array(
				'default'           => "Isletmenize Ozel",
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_title_1',
			array(
				'label' => __( 'Baslik - 1. Kisim', 'merkez-finans' ),
				'section' => 'merkez_finans_frontpage_services',
				'type'    => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_title_2',
			array(
				'default'           => 'Finansal Cozumler',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_title_2',
			array(
				'label' => __( 'Baslik - 2. Kisim (Renkli)', 'merkez-finans' ),
				'section' => 'merkez_finans_frontpage_services',
				'type'    => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_desc',
			array(
				'default'           => 'Vergiden finansmana, denetimden kurumsal danismanliga kadar tum ihtiyaclariniz icin yaninizdayiz.',
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_desc',
			array(
				'label'   => __( 'Hizmetler Aciklamasi', 'merkez-finans' ),
				'section' => 'merkez_finans_frontpage_services',
				'type'    => 'textarea',
			)
		);

		// Hizmet gosterim modu
		$wp_customize->add_setting(
			'merkez_finans_services_display_mode',
			array(
				'default'           => 'auto',
				'sanitize_callback' => function( $value ) {
					return in_array( $value, array( 'auto', 'manual' ), true ) ? $value : 'auto';
				},
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_display_mode',
			array(
				'label'       => __( 'Hizmet Gosterim Modu', 'merkez-finans' ),
				'description' => __( '"Otomatik" en son eklenen hizmetleri gosterir. "Manuel" secilen ozel hizmetleri gosterir.', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_services',
				'type'        => 'select',
				'choices'     => array(
					'auto'   => __( 'Otomatik (Son hizmetler)', 'merkez-finans' ),
					'manual' => __( 'Manuel (Ozel secim)', 'merkez-finans' ),
				),
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_count',
			array(
				'default'           => 8,
				'sanitize_callback' => 'absint',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_count',
			array(
				'label'       => __( 'Gosterilecek Hizmet Sayisi', 'merkez-finans' ),
				'description' => __( 'Anasayfada kac hizmet karti gorunecek?', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_services',
				'type'        => 'number',
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 20,
					'step' => 1,
				),
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_manual_ids',
			array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_manual_ids',
			array(
				'label'       => __( 'Manuel Hizmet ID\'leri', 'merkez-finans' ),
				'description' => __( 'Manuel mod icin virgulle ayrilmis hizmet ID\'leri. Ornek: 15,22,8. Bos birakirsan son hizmetler gosterilir.', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_services',
				'type'        => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_page_title',
			array(
				'default'           => 'Hizmetlerimiz',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_page_title',
			array(
				'label'       => __( 'Hizmet Sayfasi Basligi', 'merkez-finans' ),
				'description' => __( 'Hizmet listeleme sayfasinin basligi.', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_services',
				'type'        => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_page_subtitle',
			array(
				'default'           => 'Isletmenize ozel kapsamli finansal cozumler.',
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_page_subtitle',
			array(
				'label'   => __( 'Hizmet Sayfasi Alt Basligi', 'merkez-finans' ),
				'section' => 'merkez_finans_frontpage_services',
				'type'    => 'textarea',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_services_btn_text',
			array(
				'default'           => 'Tum Hizmetleri Incele',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_services_btn_text',
			array(
				'label'       => __( 'Hizmet Sayfasi Buton Metni', 'merkez-finans' ),
				'description' => __( 'Anasayfadaki "Tum hizmetleri gor" butonu metni.', 'merkez-finans' ),
				'section'     => 'merkez_finans_frontpage_services',
				'type'        => 'text',
			)
		);


		// --- Hero Video Ayarlari ---
		$wp_customize->add_section(
			'merkez_finans_hero',
			array(
				'title'       => __( 'Hero Video Ayarlari', 'merkez-finans' ),
				'panel'       => 'merkez_finans_panel',
				'priority'    => 49,
				'description' => __( 'Anasayfa hero bolumu arka plan video ve poster ayarlari.', 'merkez-finans' ),
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_hero_video',
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Upload_Control(
				$wp_customize,
				'merkez_finans_hero_video',
				array(
					'label'      => __( 'Hero Arka Plan Video (MP4)', 'merkez-finans' ),
					'section'    => 'merkez_finans_hero',
					'mime_type'  => 'video',
					'description' => __( 'Mobil uyumluluk icin MP4 formati onerilir. Bos birakilirsa poster gorunur.', 'merkez-finans' ),
				)
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_hero_poster',
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'merkez_finans_hero_poster',
				array(
					'label'   => __( 'Hero Poster / Arka Plan Gorseli', 'merkez-finans' ),
					'section' => 'merkez_finans_hero',
				)
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_hero_use_video',
			array(
				'default'           => true,
				'sanitize_callback' => 'wp_validate_boolean',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_hero_use_video',
			array(
				'label'       => __( 'Video Oynat', 'merkez-finans' ),
				'description' => __( 'Kapatilirsa sadece poster gorunur.', 'merkez-finans' ),
				'section'     => 'merkez_finans_hero',
				'type'        => 'checkbox',
			)
		);

		// --- Anasayfa Sektorel Cozumler Ayarlari ---
		$wp_customize->add_section(
			'merkez_finans_sectors',
			array(
				'title'       => __( 'Sektorel Cozumler Ayarlari', 'merkez-finans' ),
				'panel'       => 'merkez_finans_panel',
				'priority'    => 53,
				'description' => __( 'Anasayfadaki Sektorler bolumu iceriklerini buradan duzenleyebilirsiniz.', 'merkez-finans' ),
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_sectors_badge',
			array(
				'default'           => 'Sektorel Cozumler',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_sectors_badge',
			array(
				'label'   => __( 'Rozet (Badge) Metni', 'merkez-finans' ),
				'section' => 'merkez_finans_sectors',
				'type'    => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_sectors_title',
			array(
				'default'           => 'Sektorunuze Ozel',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_sectors_title',
			array(
				'label' => __( 'Baslik - 1. Kisim', 'merkez-finans' ),
				'section' => 'merkez_finans_sectors',
				'type'    => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_sectors_title_gradient',
			array(
				'default'           => 'Uzmanlik',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_sectors_title_gradient',
			array(
				'label' => __( 'Baslik - 2. Kisim (Renkli)', 'merkez-finans' ),
				'section' => 'merkez_finans_sectors',
				'type'    => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_sectors_desc',
			array(
				'default'           => 'Her sektorun farkli dinamiklerini bilerek, ozel cozumler uretiyoruz.',
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_sectors_desc',
			array(
				'label'   => __( 'Aciklama', 'merkez-finans' ),
				'section' => 'merkez_finans_sectors',
				'type'    => 'textarea',
			)
		);

		// 6 adet sektor karti
		$sector_defaults = array(
			array( 'title' => 'Start-up ve Girisimciler', 'desc' => 'Yeni kurulan isletmeler icin finansal altyapi, vergi planlamasi ve yatirimci raporlama hizmetleri.' ),
			array( 'title' => 'KOBİ'ler', 'desc' => 'Kucuk ve orta olceki isletmelere ozel maliyet etkin muhasebe ve finansal yonetim cozumleri.' ),
			array( 'title' => 'E-Ticaret Isletmeleri', 'desc' => 'Online satis platformlari icin ozel vergi duzenlemeleri ve finansal raporlama hizmetleri.' ),
			array( 'title' => 'Yurt Disi Islem Yapan Firmalar', 'desc' => 'Uluslararasi ticaret, transfer fiyatlandirmasi ve cifte vergilendirme anlasmalari danismanligi.' ),
			array( 'title' => 'Hizmet Sektoru', 'desc' => 'Danismanlik, egitim, saglik ve diger hizmet sektorlerine ozel finansal cozumler.' ),
			array( 'title' => 'Uretim ve Ticaret Sirketleri', 'desc' => 'Stok yonetiminden maliyet muhasebesine kadar uretim ve ticaret odakli hizmetler.' ),
		);

		foreach ( $sector_defaults as $idx => $sd ) {
			$wp_customize->add_setting(
				"merkez_finans_sector_{$idx}_title",
				array(
					'default'           => $sd['title'],
					'sanitize_callback' => 'sanitize_text_field',
					'transport'         => 'refresh',
				)
			);
			$wp_customize->add_control(
				"merkez_finans_sector_{$idx}_title",
				array(
					'label'       => sprintf( __( 'Sekt%1$s %2$d - Baslik', 'merkez-finans' ), 'o', $idx + 1 ),
					'section'     => 'merkez_finans_sectors',
					'type'        => 'text',
				)
			);

			$wp_customize->add_setting(
				"merkez_finans_sector_{$idx}_desc",
				array(
					'default'           => $sd['desc'],
					'sanitize_callback' => 'sanitize_textarea_field',
					'transport'         => 'refresh',
				)
			);
			$wp_customize->add_control(
				"merkez_finans_sector_{$idx}_desc",
				array(
					'label'       => sprintf( __( 'Sekt%1$s %2$d - Aciklama', 'merkez-finans' ), 'o', $idx + 1 ),
					'section'     => 'merkez_finans_sectors',
					'type'        => 'textarea',
				)
			);

			$wp_customize->add_setting(
				"merkez_finans_sector_{$idx}_icon",
				array(
					'default'           => 'fa-building',
					'sanitize_callback' => 'sanitize_text_field',
					'transport'         => 'refresh',
				)
			);
			$wp_customize->add_control(
				"merkez_finans_sector_{$idx}_icon",
				array(
					'label'   => sprintf( __( 'Sekt%1$s %2$d - Ikon (Font Awesome class)', 'merkez-finans' ), 'o', $idx + 1 ),
					'section' => 'merkez_finans_sectors',
					'type'    => 'text',
				)
			);
		}

		// --- Yol Haritasi (Roadmap) ---
		$wp_customize->add_section(
			'merkez_finans_roadmap',
			array(
				'title'       => __( 'Yol Haritasi (Calisma Modeli)', 'merkez-finans' ),
				'priority'    => 52,
				'description' => __( 'Anasayfadaki 4 adimli yol haritasi iceriklerini buradan duzenleyebilirsiniz.', 'merkez-finans' ),
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_roadmap_badge',
			array(
				'default'           => 'CALISMA MODELIMIZ',
				'sanitize_callback' => 'sanitize_text_field',
				'capability'        => 'edit_theme_options',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_roadmap_badge',
			array(
				'label'       => __( 'Rozet (Badge) Metni', 'merkez-finans' ),
				'section'     => 'merkez_finans_roadmap',
				'type'        => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_roadmap_title',
			array(
				'default'           => '4 Adimda Finansal Yol Haritaniz',
				'sanitize_callback' => 'sanitize_text_field',
				'capability'        => 'edit_theme_options',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_roadmap_title',
			array(
				'label'       => __( 'Bolum Basligi', 'merkez-finans' ),
				'section'     => 'merkez_finans_roadmap',
				'type'        => 'text',
			)
		);

		$wp_customize->add_setting(
			'merkez_finans_roadmap_desc',
			array(
				'default'           => 'Dort asamali mukemmellik modelimizle basariyi garantiliyoruz.',
				'sanitize_callback' => 'sanitize_textarea_field',
				'capability'        => 'edit_theme_options',
			)
		);
		$wp_customize->add_control(
			'merkez_finans_roadmap_desc',
			array(
				'label'       => __( 'Bolum Aciklamasi', 'merkez-finans' ),
				'section'     => 'merkez_finans_roadmap',
				'type'        => 'textarea',
			)
		);

		$roadmap_step_labels = array(
			__( 'Adim 1 - Ihtiyac Analizi', 'merkez-finans' ),
			__( 'Adim 2 - Strateji ve Planlama', 'merkez-finans' ),
			__( 'Adim 3 - Uygulama', 'merkez-finans' ),
			__( 'Adim 4 - Raporlama', 'merkez-finans' ),
		);
		$roadmap_step_defaults = array(
			'Ihtiyac Analizi',
			'Strateji ve Planlama',
			'Uygulama',
			'Raporlama',
		);
		$roadmap_desc_defaults = array(
			'Mevcut mali tablo ve sureclerinizi inceler, hedeflerinizi netlestiririz.',
			'Vergi, raporlama ve nakit akisi icin ozel yol haritasi kurariz.',
			'Operasyonu ustlenir, mevzuata uygun sekilde yuruturuz.',
			'Sonuclari periyodik olarak seffaf raporlarla sunuyoruz.',
		);

		foreach ( $roadmap_step_labels as $index => $label ) {
			$wp_customize->add_setting(
				"merkez_finans_roadmap_step_{$index}_title",
				array(
					'default'           => $roadmap_step_defaults[ $index ],
					'sanitize_callback' => 'sanitize_text_field',
					'capability'        => 'edit_theme_options',
				)
			);
			$wp_customize->add_control(
				"merkez_finans_roadmap_step_{$index}_title",
				array(
					'label'       => $label . ' ' . __( '(Baslik)', 'merkez-finans' ),
					'section'     => 'merkez_finans_roadmap',
					'type'        => 'text',
				)
			);

			$wp_customize->add_setting(
				"merkez_finans_roadmap_step_{$index}_desc",
				array(
					'default'           => $roadmap_desc_defaults[ $index ],
					'sanitize_callback' => 'sanitize_textarea_field',
					'capability'        => 'edit_theme_options',
				)
			);
			$wp_customize->add_control(
				"merkez_finans_roadmap_step_{$index}_desc",
				array(
					'label'       => $label . ' ' . __( '(Aciklama)', 'merkez-finans' ),
					'section'     => 'merkez_finans_roadmap',
					'type'        => 'textarea',
				)
			);
		}

	}
endif;
add_action( 'customize_register', 'merkez_finans_customize_register' );

// ============================================================
// 8. CUSTOMIZER RENKLERINI CSS'E AKTAR
// ============================================================

if ( ! function_exists( 'merkez_finans_customizer_css' ) ) :
	/**
	 * Customizer'dan gelen renk ayarlarini inline CSS olarak ekle.
	 *
	 * @return void
	 */
	function merkez_finans_customizer_css(): void {

		$primary_color = get_theme_mod( 'merkez_finans_primary_color', '#071B3A' );
		$accent_color  = get_theme_mod( 'merkez_finans_accent_color', '#2EA8FF' );

		$custom_css = sprintf(
			':root { --color-navy: %s; --color-navy-800: %s; --color-accent: %s; --color-accent-400: %s; }',
			esc_attr( $primary_color ),
			esc_attr( $primary_color ),
			esc_attr( $accent_color ),
			esc_attr( $accent_color )
		);

		wp_add_inline_style( 'merkez-finans-style', $custom_css );

	}
endif;
add_action( 'wp_enqueue_scripts', 'merkez_finans_customizer_css', 20 );

// ============================================================
// 9. ILETISIM BILGISI YARDIMCI FONKSIYONLARI
// ============================================================

if ( ! function_exists( 'merkez_finans_get_contact' ) ) :
	/**
	 * Iletisim bilgilerini guvenli sekilde getir.
	 *
	 * @param string $key Bilgi anahtari.
	 * @return string
	 */
	function merkez_finans_get_contact( string $key ): string {

		$defaults = array(
			'phone'         => '0212 123 45 67',
			'email'         => 'info@merkezfinans.com',
			'address'       => "Levent Mah. Finans Cad. No:42\nBesiktas/Istanbul",
			'working_hours' => 'Pazartesi - Cuma: 09:00 - 18:00',
			'whatsapp'      => '902121234567',
		);

		$value = get_theme_mod( "merkez_finans_{$key}", $defaults[ $key ] ?? '' );

		return esc_html( $value );

	}
endif;

if ( ! function_exists( 'merkez_finans_get_social' ) ) :
	/**
	 * Sosyal medya linkini guvenli sekilde getir.
	 *
	 * @param string $network Sosyal ag adi.
	 * @return string
	 */
	function merkez_finans_get_social( string $network ): string {

		$url = get_theme_mod( "merkez_finans_social_{$network}", '' );
		return esc_url( $url );

	}
endif;

// ============================================================
// 10. GUTENBERG / BLOCK EDITOR DESTEGI
// ============================================================

if ( ! function_exists( 'merkez_finans_block_editor_assets' ) ) :
	/**
	 * Block editor (Gutenberg) icin stil ve script yukle.
	 *
	 * @return void
	 */
	function merkez_finans_block_editor_assets(): void {

		wp_enqueue_style(
			'merkez-finans-editor',
			MERKEZ_FINANS_URI . '/assets/css/editor.css',
			array(),
			MERKEZ_FINANS_VERSION
		);

		wp_enqueue_script(
			'merkez-finans-editor',
			MERKEZ_FINANS_URI . '/assets/js/editor.js',
			array( 'wp-blocks', 'wp-dom', 'wp-dom-ready', 'wp-edit-post' ),
			MERKEZ_FINANS_VERSION,
			true
		);

	}
endif;
add_action( 'enqueue_block_editor_assets', 'merkez_finans_block_editor_assets' );

// ============================================================
// 11. OG & META TAG YARDIMCILARI
// ============================================================

if ( ! function_exists( 'merkez_finans_meta_tags' ) ) :
	/**
	 * SEO meta tag'lerini head bolumune ekle.
	 *
	 * @return void
	 */
	function merkez_finans_meta_tags(): void {

		// Viewport
		echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">' . "\n";

		// Theme color (mobil browser)
		echo '<meta name="theme-color" content="#071B3A">' . "\n";

		// Open Graph - site adi
		if ( is_front_page() ) {
			echo '<meta property="og:type" content="website">' . "\n";
		} else {
			echo '<meta property="og:type" content="article">' . "\n";
		}

	}
endif;
add_action( 'wp_head', 'merkez_finans_meta_tags', 1 );

// ============================================================
// 12. EXCERPT UZUNLUGU AYARI
// ============================================================

if ( ! function_exists( 'merkez_finans_excerpt_length' ) ) :
	/**
	 * Blog ozet metni uzunlugunu ayarla.
	 *
	 * @return int
	 */
	function merkez_finans_excerpt_length(): int {
		return 20;
	}
endif;
add_filter( 'excerpt_length', 'merkez_finans_excerpt_length', 999 );

if ( ! function_exists( 'merkez_finans_excerpt_more' ) ) :
	/**
	 * Blog ozet metni "devami" baglantisini ozellestir.
	 *
	 * @return string
	 */
	function merkez_finans_excerpt_more(): string {
		return '...';
	}
endif;
add_filter( 'excerpt_more', 'merkez_finans_excerpt_more' );

if ( ! function_exists( 'merkez_finans_trim_text' ) ) :
	/**
	 * Metni belirli karaktere kes.
	 *
	 * @param string $text Metin.
	 * @param int    $limit Karakter limiti.
	 * @return string
	 */
	function merkez_finans_trim_text( string $text, int $limit = 120 ): string {
		if ( mb_strlen( $text ) <= $limit ) {
			return $text;
		}
		return mb_substr( $text, 0, $limit ) . '...';
	}
endif;

// ============================================================
// 13. GUTENBERG BLOCK CATEGORIES (OZEL)
// ============================================================

if ( ! function_exists( 'merkez_finans_block_categories' ) ) :
	/**
	 * Ozel Gutenberg block kategorisi ekle.
	 *
	 * @param array $categories Mevcut kategoriler.
	 * @return array
	 */
	function merkez_finans_block_categories( array $categories ): array {

		return array_merge(
			$categories,
			array(
				array(
					'slug'  => 'merkez-finans',
					'title' => __( 'Merkez Finans Bloklari', 'merkez-finans' ),
					'icon'  => 'chart-line',
				),
			)
		);

	}
endif;
add_filter( 'block_categories_all', 'merkez_finans_block_categories' );

// ============================================================
// 14. SECURITY HEADERS
// ============================================================

if ( ! function_exists( 'merkez_finans_security_headers' ) ) :
	/**
	 * Guvenlik basliklarini HTTP yanitina ekle.
	 *
	 * @return void
	 */
	function merkez_finans_security_headers(): void {

		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );

	}
endif;
add_action( 'send_headers', 'merkez_finans_security_headers' );

// ============================================================
// 15. DISALLOW FILE EDIT (GUvenlik)
// ============================================================

if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

// ============================================================
// 16. REMOVE WP EMOJI SCRIPTS (PERFORMANS)
// ============================================================

remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );

// ============================================================
// 17. GUTENBERG BLOCK STYLES (UNREGISTER)
// ============================================================

if ( ! function_exists( 'merkez_finans_unregister_block_styles' ) ) :
	/**
	 * Kullanilmayan varsayilan block stillerini kaldir.
	 *
	 * @return void
	 */
	function merkez_finans_unregister_block_styles(): void {

		// Ornek: Gerekirse buradan block stilleri kaldirilabilir
		// unregister_block_style( 'core/button', 'outline' );

	}
endif;
add_action( 'init', 'merkez_finans_unregister_block_styles' );

// ============================================================
// 18. CUSTOM POST TYPE: HIZMETLER (OPSiyonel)
// ============================================================

if ( ! function_exists( 'merkez_finans_register_service_post_type' ) ) :
	/**
	 * Hizmetler ozel icerik turunu kaydet.
	 *
	 * @return void
	 */
	function merkez_finans_register_service_post_type(): void {

		$labels = array(
			'name'                  => __( 'Hizmetler', 'merkez-finans' ),
			'singular_name'         => __( 'Hizmet', 'merkez-finans' ),
			'menu_name'            => __( 'Hizmetler', 'merkez-finans' ),
			'name_admin_bar'       => __( 'Hizmet', 'merkez-finans' ),
			'add_new'              => __( 'Yeni Ekle', 'merkez-finans' ),
			'add_new_item'         => __( 'Yeni Hizmet Ekle', 'merkez-finans' ),
			'new_item'             => __( 'Yeni Hizmet', 'merkez-finans' ),
			'edit_item'            => __( 'Hizmeti Duzenle', 'merkez-finans' ),
			'view_item'            => __( 'Hizmeti Goruntule', 'merkez-finans' ),
			'all_items'            => __( 'Tum Hizmetler', 'merkez-finans' ),
			'search_items'         => __( 'Hizmet Ara', 'merkez-finans' ),
			'not_found'            => __( 'Hizmet bulunamadi.', 'merkez-finans' ),
			'not_found_in_trash'   => __( 'Cop kutusunda hizmet bulunamadi.', 'merkez-finans' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'hizmet' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 5,
			'menu_icon'          => 'dashicons-chart-line',
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'revisions' ),
			'show_in_rest'       => true,
			'taxonomies'         => array( 'service_category' ),
		);

		register_post_type( 'service', $args );

		// Hizmet Kategorileri (Taksonomi)
		$cat_labels = array(
			'name'          => __( 'Hizmet Kategorileri', 'merkez-finans' ),
			'singular_name' => __( 'Hizmet Kategorisi', 'merkez-finans' ),
		);

		$cat_args = array(
			'labels'        => $cat_labels,
			'hierarchical'  => true,
			'public'        => true,
			'rewrite'       => array( 'slug' => 'hizmet-kategori' ),
			'show_in_rest'  => true,
		);

		register_taxonomy( 'service_category', array( 'service' ), $cat_args );

	}
endif;
add_action( 'init', 'merkez_finans_register_service_post_type' );

// ============================================================
// 19. AJAX HANDLER (Guvenli)
// ============================================================

if ( ! function_exists( 'merkez_finans_ajax_handler' ) ) :
	/**
	 * Guvenli AJAX isteklerini isle.
	 *
	 * @return void
	 */
	function merkez_finans_ajax_handler(): void {

		// Nonce dogrulama
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'merkez_finans_nonce' ) ) {
			wp_send_json_error( __( 'Guvenlik dogrulamasi basarisiz.', 'merkez-finans' ), 403 );
		}

		// Yetki kontrolu
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( __( 'Yetkisiz erisim.', 'merkez-finans' ), 401 );
		}

		$action = isset( $_POST['action_type'] ) ? sanitize_text_field( wp_unslash( $_POST['action_type'] ) ) : '';

		switch ( $action ) {
			case 'load_more_posts':
				// Sayfalama mantigi burada
				wp_send_json_success( array( 'message' => __( 'Icerik yuklendi.', 'merkez-finans' ) ) );
				break;

			default:
				wp_send_json_error( __( 'Bilinmeyen islem.', 'merkez-finans' ), 400 );
				break;
		}

	}
endif;
add_action( 'wp_ajax_merkez_finans_action', 'merkez_finans_ajax_handler' );
add_action( 'wp_ajax_nopriv_merkez_finans_action', 'merkez_finans_ajax_handler' );

// ============================================================
// 19b. NEWSLETTER AJAX HANDLER
// ============================================================

if ( ! function_exists( 'merkez_finans_newsletter_subscribe' ) ) :
	/**
	 * Newsletter abonelik AJAX handler.
	 *
	 * @return void
	 */
	function merkez_finans_newsletter_subscribe(): void {

		// Nonce kontrolu
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'merkez_finans_newsletter' ) ) {
			wp_send_json_error( array( 'message' => __( 'Guvenlik dogrulamasi basarisiz.', 'merkez-finans' ) ), 403 );
		}

		$email = isset( $_POST['subscriber_email'] ) ? sanitize_email( wp_unslash( $_POST['subscriber_email'] ) ) : '';

		if ( empty( $email ) || ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'Lutfen gecerli bir e-posta adresi girin.', 'merkez-finans' ) ), 400 );
		}

		// WordPress native subscriber listesi (option olarak sakla)
		$subscribers = get_option( 'merkez_finans_subscribers', array() );

		if ( in_array( $email, $subscribers, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Bu e-posta adresi zaten kayitli.', 'merkez-finans' ) ), 409 );
		}

		$subscribers[] = $email;
		update_option( 'merkez_finans_subscribers', $subscribers );

		// Admin'e bildirim gonder
		$admin_email = get_option( 'admin_email' );
		$subject     = __( 'Yeni Bulten Abonesi - ', 'merkez-finans' ) . get_bloginfo( 'name' );
		$message     = __( 'Yeni bir bulten abonesi:', 'merkez-finans' ) . ' ' . $email;
		wp_mail( $admin_email, $subject, $message );

		wp_send_json_success( array( 'message' => __( 'Aboneliğiniz basariyla alinmistir.', 'merkez-finans' ) ) );

	}
endif;
add_action( 'wp_ajax_merkez_finans_subscribe', 'merkez_finans_newsletter_subscribe' );
add_action( 'wp_ajax_nopriv_merkez_finans_subscribe', 'merkez_finans_newsletter_subscribe' );

// ============================================================
// 20. SCHEMA.ORG JSON-LD HELPER
// ============================================================

if ( ! function_exists( 'merkez_finans_schema_local_business' ) ) :
	/**
	 * LocalBusiness Schema.org JSON-LD ciktisi uret.
	 *
	 * @return string
	 */
	function merkez_finans_schema_local_business(): string {

		$schema = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'ProfessionalService',
			'name'        => get_bloginfo( 'name' ),
			'description' => get_bloginfo( 'description' ),
			'url'         => esc_url( home_url( '/' ) ),
			'telephone'   => merkez_finans_get_contact( 'phone' ),
			'email'       => sanitize_email( merkez_finans_get_contact( 'email' ) ),
			'address'     => array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => 'Levent Mah. Finans Cad. No:42',
				'addressLocality' => 'Besiktas',
				'addressRegion'   => 'Istanbul',
				'postalCode'      => '34330',
				'addressCountry'  => 'TR',
			),
			'geo'         => array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => '41.0825',
				'longitude' => '29.0136',
			),
			'openingHoursSpecification' => array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday' ),
				'opens'     => '09:00',
				'closes'    => '18:00',
			),
			'priceRange'  => '$$',
			'areaServed'  => 'TR',
		);

		return wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

	}
endif;

if ( ! function_exists( 'merkez_finans_output_schema' ) ) :
	/**
	 * Schema.org JSON-LD'yi sayfaya yazdir.
	 *
	 * @return void
	 */
	function merkez_finans_output_schema(): void {

		if ( ! is_front_page() ) {
			return;
		}

		$schema_json = merkez_finans_schema_local_business();

		echo '<script type="application/ld+json">' . wp_kses_post( $schema_json ) . '</script>' . "\n";

	}
endif;
add_action( 'wp_head', 'merkez_finans_output_schema', 5 );

// ============================================================
// 21. BREADCRUMB FONKSIYONU
// ============================================================

if ( ! function_exists( 'merkez_finans_breadcrumbs' ) ) :
	/**
	 * Breadcrumb (navigasyon kivircigi) HTML ciktisi uret.
	 *
	 * @return string
	 */
	function merkez_finans_breadcrumbs(): string {

		$sep = '<span class="breadcrumb-sep" aria-hidden="true">/</span>';
		$html = '<nav class="breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'merkez-finans' ) . '">';
		$html .= '<ol class="breadcrumb-list">';
		$html .= '<li class="breadcrumb-item"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Ana Sayfa', 'merkez-finans' ) . '</a></li>';

		if ( is_single() ) {
			$html .= $sep;
			$category = get_the_category();
			if ( ! empty( $category ) ) {
				$html .= '<li class="breadcrumb-item"><a href="' . esc_url( get_category_link( $category[0]->term_id ) ) . '">' . esc_html( $category[0]->name ) . '</a></li>';
				$html .= $sep;
			}
			$html .= '<li class="breadcrumb-item current" aria-current="page">' . esc_html( get_the_title() ) . '</li>';
		} elseif ( is_page() ) {
			$html .= $sep;
			$html .= '<li class="breadcrumb-item current" aria-current="page">' . esc_html( get_the_title() ) . '</li>';
		} elseif ( is_category() ) {
			$html .= $sep;
			$html .= '<li class="breadcrumb-item current" aria-current="page">' . esc_html( single_cat_title( '', false ) ) . '</li>';
		} elseif ( is_archive() ) {
			$html .= $sep;
			$html .= '<li class="breadcrumb-item current" aria-current="page">' . wp_kses_post( get_the_archive_title() ) . '</li>';
		} elseif ( is_search() ) {
			$html .= $sep;
			$html .= '<li class="breadcrumb-item current" aria-current="page">' . esc_html__( 'Arama Sonuclari', 'merkez-finans' ) . '</li>';
		} elseif ( is_404() ) {
			$html .= $sep;
			$html .= '<li class="breadcrumb-item current" aria-current="page">' . esc_html__( 'Sayfa Bulunamadi', 'merkez-finans' ) . '</li>';
		}

		$html .= '</ol>';
		$html .= '</nav>';

		return $html;

	}
endif;

// ============================================================
// 22. PAGINATION FONKSIYONU
// ============================================================

if ( ! function_exists( 'merkez_finans_pagination' ) ) :
	/**
	 * Sayfalama HTML ciktisi uret.
	 *
	 * @return string
	 */
	function merkez_finans_pagination(): string {

		global $wp_query;

		$big = 999999999;

		$paginate_links = paginate_links(
			array(
				'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
				'format'    => '?paged=%#%',
				'current'   => max( 1, get_query_var( 'paged' ) ),
				'total'     => $wp_query->max_num_pages,
				'prev_text' => '<span aria-hidden="true">&larr;</span> ' . esc_html__( 'Onceki', 'merkez-finans' ),
				'next_text' => esc_html__( 'Sonraki', 'merkez-finans' ) . ' <span aria-hidden="true">&rarr;</span>',
				'mid_size'  => 2,
				'type'      => 'list',
			)
		);

		if ( $paginate_links ) {
			return '<nav class="pagination-nav" aria-label="' . esc_attr__( 'Sayfalama', 'merkez-finans' ) . '">' . wp_kses_post( $paginate_links ) . '</nav>';
		}

		return '';

	}
endif;

// ============================================================
// 23. READING TIME FONKSIYONU
// ============================================================

if ( ! function_exists( 'merkez_finans_reading_time' ) ) :
	/**
	 * Blog yazisi okuma suresini hesapla.
	 *
	 * @param int|null $post_id Post ID.
	 * @return string
	 */
	function merkez_finans_reading_time( ?int $post_id = null ): string {

		$post = get_post( $post_id );

		if ( ! $post ) {
			return '';
		}

		$content = strip_tags( $post->post_content );
		$word_count = str_word_count( $content );
		$minutes = max( 1, (int) ceil( $word_count / 200 ) );

		return sprintf(
			/* translators: %d: Okuma suresi (dakika) */
			esc_html__( '%d dk okuma', 'merkez-finans' ),
			$minutes
		);

	}
endif;

// ============================================================
// 24. SOCIAL SHARE FONKSIYONU
// ============================================================

if ( ! function_exists( 'merkez_finans_social_share' ) ) :
	/**
	 * Sosyal paylasim butonlari HTML ciktisi uret.
	 *
	 * @return string
	 */
	function merkez_finans_social_share(): string {

		$title = rawurlencode( get_the_title() );
		$url   = rawurlencode( get_permalink() );

		$html  = '<div class="social-share">';
		$html .= '<span class="social-share-label">' . esc_html__( 'Paylas:', 'merkez-finans' ) . '</span>';
		$html .= '<a href="https://www.linkedin.com/sharing/share-offsite/?url=' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer" class="social-share-link" aria-label="' . esc_attr__( 'LinkedIn\'de paylas', 'merkez-finans' ) . '"><i class="fab fa-linkedin"></i></a>';
		$html .= '<a href="https://twitter.com/intent/tweet?text=' . esc_attr( $title ) . '&url=' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer" class="social-share-link" aria-label="' . esc_attr__( 'Twitter\'da paylas', 'merkez-finans' ) . '"><i class="fab fa-x-twitter"></i></a>';
		$html .= '<a href="https://wa.me/?text=' . esc_attr( $title ) . '%20' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer" class="social-share-link" aria-label="' . esc_attr__( 'WhatsApp\'ta paylas', 'merkez-finans' ) . '"><i class="fab fa-whatsapp"></i></a>';
		$html .= '</div>';

		return $html;

	}
endif;

// ============================================================
// 25. FORM SHORTCODE (Iletisim)
// ============================================================

if ( ! function_exists( 'merkez_finans_contact_form_shortcode' ) ) :
	/**
	 * Iletisim formu shortcode'u.
	 *
	 * @param array $atts Shortcode attributeleri.
	 * @return string
	 */
	function merkez_finans_contact_form_shortcode( array $atts ): string {

		$atts = shortcode_atts(
			array(
				'title' => __( 'Bize Ulasin', 'merkez-finans' ),
			),
			$atts,
			'contact_form'
		);

		ob_start();
		?>
		<form class="contact-form" method="post" action="" novalidate>
			<?php wp_nonce_field( 'merkez_finans_contact', 'contact_nonce' ); ?>
			<h3><?php echo esc_html( $atts['title'] ); ?></h3>

			<div class="form-row">
				<div class="form-group">
					<label for="contact-name"><?php esc_html_e( 'Ad Soyad', 'merkez-finans' ); ?> *</label>
					<input type="text" id="contact-name" name="contact_name" required class="form-control">
				</div>
				<div class="form-group">
					<label for="contact-phone"><?php esc_html_e( 'Telefon', 'merkez-finans' ); ?> *</label>
					<input type="tel" id="contact-phone" name="contact_phone" required class="form-control">
				</div>
			</div>

			<div class="form-row">
				<div class="form-group">
					<label for="contact-email"><?php esc_html_e( 'E-posta', 'merkez-finans' ); ?> *</label>
					<input type="email" id="contact-email" name="contact_email" required class="form-control">
				</div>
				<div class="form-group">
					<label for="contact-company"><?php esc_html_e( 'Sirket Adi', 'merkez-finans' ); ?></label>
					<input type="text" id="contact-company" name="contact_company" class="form-control">
				</div>
			</div>

			<div class="form-group">
				<label for="contact-service"><?php esc_html_e( 'Hizmet Secimi', 'merkez-finans' ); ?> *</label>
				<select id="contact-service" name="contact_service" required class="form-control">
					<option value=""><?php esc_html_e( 'Hizmet Seciniz', 'merkez-finans' ); ?></option>
					<option value="muhasebe"><?php esc_html_e( 'Muhasebe ve Vergi Cozumleri', 'merkez-finans' ); ?></option>
					<option value="vergi"><?php esc_html_e( 'Vergi Danismanligi', 'merkez-finans' ); ?></option>
					<option value="raporlama"><?php esc_html_e( 'Finansal Raporlama', 'merkez-finans' ); ?></option>
					<option value="denetim"><?php esc_html_e( 'Denetim ve Ic Kontrol', 'merkez-finans' ); ?></option>
					<option value="kurulus"><?php esc_html_e( 'Sirket Kurulusu', 'merkez-finans' ); ?></option>
					<option value="bordro"><?php esc_html_e( 'Bordro Yonetimi', 'merkez-finans' ); ?></option>
					<option value="finansman"><?php esc_html_e( 'Kurumsal Finansman', 'merkez-finans' ); ?></option>
					<option value="uluslararasi"><?php esc_html_e( 'Uluslararasi Danismanlik', 'merkez-finans' ); ?></option>
				</select>
			</div>

			<div class="form-group">
				<label for="contact-message"><?php esc_html_e( 'Mesaj', 'merkez-finans' ); ?></label>
				<textarea id="contact-message" name="contact_message" rows="4" class="form-control"></textarea>
			</div>

			<div class="form-group form-checkbox">
				<input type="checkbox" id="contact-kvkk" name="contact_kvkk" required>
				<label for="contact-kvkk">
					<?php
					echo wp_kses_post(
						sprintf(
							/* translators: %s: KVKK linki */
							__( '<a href="%s" target="_blank">KVKK Aydinlatma Metni</a>\'ni okudum ve kisisel verilerimin islenmesine riza gosteriyorum.', 'merkez-finans' ),
							esc_url( get_privacy_policy_url() )
						)
					);
					?>
				</label>
			</div>

			<button type="submit" class="btn btn-primary">
				<?php esc_html_e( 'Formu Gonder', 'merkez-finans' ); ?>
			</button>
		</form>
		<?php
		return ob_get_clean();

	}
endif;
add_shortcode( 'contact_form', 'merkez_finans_contact_form_shortcode' );

// ============================================================
// 26. BODY CLASS FILTERS
// ============================================================

if ( ! function_exists( 'merkez_finans_body_classes' ) ) :
	/**
	 * Body elementine ozel siniflar ekle.
	 *
	 * @param array $classes Mevcut siniflar.
	 * @return array
	 */
	function merkez_finans_body_classes( array $classes ): array {

		if ( is_front_page() ) {
			$classes[] = 'is-front-page';
		}

		if ( is_singular() ) {
			$classes[] = 'is-singular';
		}

		if ( has_post_thumbnail() ) {
			$classes[] = 'has-post-thumbnail';
		}

		return $classes;

	}
endif;
add_filter( 'body_class', 'merkez_finans_body_classes' );

// ============================================================
// 27. COMMENTS TEMPLATE OZELLESTIRME
// ============================================================

if ( ! function_exists( 'merkez_finans_comment_template' ) ) :
	/**
	 * Yorum HTML ciktisini ozellestir.
	 *
	 * @param WP_Comment $comment Yorum nesnesi.
	 * @param array      $args    Argumanlar.
	 * @param int        $depth   Derinlik.
	 * @return void
	 */
	function merkez_finans_comment_template( WP_Comment $comment, array $args, int $depth ): void {

		$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
		?>
		<<?php echo esc_attr( $tag ); ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent', $comment ); ?>>
			<article id="div-comment-<?php comment_ID(); ?>" class="comment-body">
				<footer class="comment-meta">
					<div class="comment-author vcard">
						<?php
						if ( 0 !== $args['avatar_size'] ) {
							echo get_avatar( $comment, $args['avatar_size'], '', '', array( 'class' => 'comment-avatar' ) );
						}
						?>
						<?php
						printf(
							'<b class="fn">%s</b> <span class="says">%s</span>',
							get_comment_author_link( $comment ),
							esc_html__( 'diyor ki:', 'merkez-finans' )
						);
						?>
					</div>
					<div class="comment-metadata">
						<a href="<?php echo esc_url( get_comment_link( $comment, $args ) ); ?>">
							<time datetime="<?php comment_time( 'c' ); ?>">
								<?php
								printf(
									esc_html__( '%1$s saat %2$s', 'merkez-finans' ),
									get_comment_date( '', $comment ),
									get_comment_time()
								);
								?>
							</time>
						</a>
						<?php edit_comment_link( esc_html__( 'Duzenle', 'merkez-finans' ), '<span class="edit-link">', '</span>' ); ?>
					</div>
					<?php if ( '0' === $comment->comment_approved ) : ?>
						<p class="comment-awaiting-moderation"><?php esc_html_e( 'Yorumunuz onay bekliyor.', 'merkez-finans' ); ?></p>
					<?php endif; ?>
				</footer>
				<div class="comment-content">
					<?php comment_text(); ?>
				</div>
				<div class="reply">
					<?php
					comment_reply_link(
						array_merge(
							$args,
							array(
								'add_below' => 'div-comment',
								'depth'     => $depth,
								'max_depth' => $args['max_depth'],
								'reply_text' => esc_html__( 'Yanıtla', 'merkez-finans' ),
							)
						)
					);
					?>
				</div>
			</article>
		<?php
	}
endif;

// ============================================================
// 28. LOGIN PAGE LOGO LINK
// ============================================================

if ( ! function_exists( 'merkez_finans_login_logo_url' ) ) :
	/**
	 * Giris sayfasi logosunun baglantisini ana sayfaya yonlendir.
	 *
	 * @return string
	 */
	function merkez_finans_login_logo_url(): string {
		return esc_url( home_url( '/' ) );
	}
endif;
add_filter( 'login_headerurl', 'merkez_finans_login_logo_url' );

if ( ! function_exists( 'merkez_finans_login_logo_url_title' ) ) :
	/**
	 * Giris sayfasi logosunun title metni.
	 *
	 * @return string
	 */
	function merkez_finans_login_logo_url_title(): string {
		return esc_attr( get_bloginfo( 'name' ) );
	}
endif;
add_filter( 'login_headertext', 'merkez_finans_login_logo_url_title' );

// ============================================================
// 29. HEARTBEAT API OPTIMIZASYONU (PERFORMANS)
// ============================================================

if ( ! function_exists( 'merkez_finans_heartbeat_settings' ) ) :
	/**
	 * Heartbeat API araligini optimize et.
	 *
	 * @param array $settings Mevcut ayarlar.
	 * @return array
	 */
	function merkez_finans_heartbeat_settings( array $settings ): array {

		$settings['interval'] = 60; // 60 saniye
		return $settings;

	}
endif;
add_filter( 'heartbeat_settings', 'merkez_finans_heartbeat_settings' );

// ============================================================
// 30. REMOVE GUTENBERG DEFAULT FONT SIZES (CUSTOM ONES ONLY)
// ============================================================

add_theme_support( 'editor-font-sizes', array() );

// ============================================================
// 31. SVG UPLOAD IZNI (Guvenli)
// ============================================================

if ( ! function_exists( 'merkez_finans_mime_types' ) ) :
	/**
	 * SVG yuklemesine izin ver (guvenlik kontrollu).
	 *
	 * @param array $mimes Mevcut MIME turleri.
	 * @return array
	 */
	function merkez_finans_mime_types( array $mimes ): array {

		if ( current_user_can( 'administrator' ) ) {
			$mimes['svg'] = 'image/svg+xml';
		}
		return $mimes;

	}
endif;
add_filter( 'upload_mimes', 'merkez_finans_mime_types' );

// ============================================================
// 32. SVG SANITIZATION (Guvenlik)
// ============================================================

if ( ! function_exists( 'merkez_finans_sanitize_svg' ) ) :
	/**
	 * SVG icerigini guvenli hale getir.
	 *
	 * @param array $file Yuklenen dosya bilgisi.
	 * @return array
	 */
	function merkez_finans_sanitize_svg( array $file ): array {

		if ( 'image/svg+xml' === $file['type'] ) {
			$content = file_get_contents( $file['tmp_name'] );

			// Tehlikeli etiketleri ve attribute'lari kaldir
			$dangerous = array(
				'script',
				'foreignObject',
				'iframe',
				'embed',
				'object',
			);

			foreach ( $dangerous as $tag ) {
				$content = preg_replace( '/<(' . $tag . ')[^>]*>.*?<\/\1>/is', '', $content );
				$content = preg_replace( '/<(' . $tag . ')[^>]*\/>/is', '', $content );
			}

			// Event handler'lari kaldir
			$content = preg_replace( '/on\w+\s*=\s*"[^"]*"/i', '', $content );
			$content = preg_replace( '/on\w+\s*=\s*\'[^\']*\'/i', '', $content );

			file_put_contents( $file['tmp_name'], $content );
		}

		return $file;

	}
endif;
add_filter( 'wp_handle_upload_prefilter', 'merkez_finans_sanitize_svg' );

// ============================================================
// 33. TEMA KURULUM FONKSIYONU (after_switch_theme)
// ============================================================

if ( ! function_exists( 'merkez_finans_theme_setup' ) ) :
	/**
	 * Tema ilk kuruldugunda varsayilan sayfalari, menuleri ve ayarlari olustur.
	 *
	 * @return void
	 */
	function merkez_finans_theme_setup(): void {

		// Daha once kurulum yapildi mi kontrol et
		if ( get_option( 'merkez_finans_setup_done' ) ) {
			return;
		}

		// --- 1. Varsayilan Sayfalari Olustur ---

		// Blog sayfasi
		$blog_page = get_page_by_path( 'blog' );
		if ( ! $blog_page ) {
			$blog_page_id = wp_insert_post(
				array(
					'post_title'   => __( 'Blog', 'merkez-finans' ),
					'post_content' => '',
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_name'    => 'blog',
				)
			);
		} else {
			$blog_page_id = $blog_page->ID;
		}

		// --- 2. Ayarlar > Okuma ---
		// Anasayfa: "Son yazilar" yerine static front page kullan
		$front_page = get_page_by_path( 'anasayfa' );
		if ( ! $front_page ) {
			// front-page.php kullaniliyor, ayarlari degistirme
		}

		// Blog sayfasini Yazilar Sayfasi olarak ayarla
		if ( $blog_page_id ) {
			update_option( 'page_for_posts', $blog_page_id );
		}

		// --- 3. Header Menusu Olustur ---
		$menu_name    = __( 'Ana Menu', 'merkez-finans' );
		$existing_menu = wp_get_nav_menu_object( $menu_name );

		if ( ! $existing_menu ) {
			$menu_id = wp_create_nav_menu( $menu_name );

			if ( $menu_id && ! is_wp_error( $menu_id ) ) {
				// Anasayfa
				wp_update_nav_menu_item(
					$menu_id,
					0,
					array(
						'menu-item-title'     => __( 'Anasayfa', 'merkez-finans' ),
						'menu-item-url'       => home_url( '/' ),
						'menu-item-status'    => 'publish',
						'menu-item-type'      => 'custom',
						'menu-item-position'  => 1,
					)
				);

				// Hizmetler (arşiv sayfasi)
			$service_archive = get_post_type_archive_link( 'service' );
			if ( ! $service_archive ) {
				$service_archive = home_url( '/hizmet/' );
			}
			wp_update_nav_menu_item(
				$menu_id,
				0,
				array(
					'menu-item-title'     => __( 'Hizmetler', 'merkez-finans' ),
					'menu-item-url'       => $service_archive,
					'menu-item-status'    => 'publish',
					'menu-item-type'      => 'custom',
					'menu-item-position'  => 2,
				)
			);

				// Hakkimizda (anchor)
				wp_update_nav_menu_item(
					$menu_id,
					0,
					array(
						'menu-item-title'     => __( 'Hakkimizda', 'merkez-finans' ),
						'menu-item-url'       => home_url( '/#about' ),
						'menu-item-status'    => 'publish',
						'menu-item-type'      => 'custom',
						'menu-item-position'  => 3,
					)
				);

				// Blog (sayfa)
				if ( $blog_page_id ) {
					wp_update_nav_menu_item(
						$menu_id,
						0,
						array(
							'menu-item-title'     => __( 'Blog', 'merkez-finans' ),
							'menu-item-object-id' => $blog_page_id,
							'menu-item-object'    => 'page',
							'menu-item-type'      => 'post_type',
							'menu-item-status'    => 'publish',
							'menu-item-position'  => 4,
						)
					);
				}

				// Sektörler (anchor)
				wp_update_nav_menu_item(
					$menu_id,
					0,
					array(
						'menu-item-title'     => __( 'Sektorler', 'merkez-finans' ),
						'menu-item-url'       => home_url( '/#sectors' ),
						'menu-item-status'    => 'publish',
						'menu-item-type'      => 'custom',
						'menu-item-position'  => 5,
					)
				);

				// Iletisim (anchor)
				wp_update_nav_menu_item(
					$menu_id,
					0,
					array(
						'menu-item-title'     => __( 'Iletisim', 'merkez-finans' ),
						'menu-item-url'       => home_url( '/#contact' ),
						'menu-item-status'    => 'publish',
						'menu-item-type'      => 'custom',
						'menu-item-position'  => 6,
					)
				);

				// Menu konumuna ata
				$locations = get_theme_mod( 'nav_menu_locations' );
				if ( ! is_array( $locations ) ) {
					$locations = array();
				}
				$locations['primary'] = $menu_id;
				set_theme_mod( 'nav_menu_locations', $locations );
			}
		}

		// --- 4. Varsayilan Kategoriler ---
		if ( ! term_exists( 'Vergi', 'category' ) ) {
			wp_insert_term( __( 'Vergi', 'merkez-finans' ), 'category' );
		}
		if ( ! term_exists( 'Muhasebe', 'category' ) ) {
			wp_insert_term( __( 'Muhasebe', 'merkez-finans' ), 'category' );
		}
		if ( ! term_exists( 'Finans', 'category' ) ) {
			wp_insert_term( __( 'Finans', 'merkez-finans' ), 'category' );
		}

		// Kurulum tamamlandi isaretle
		update_option( 'merkez_finans_setup_done', true );

	}
endif;
add_action( 'after_switch_theme', 'merkez_finans_theme_setup' );

// ============================================================
// 34. TEMA KAPATMA - TEMIZLIK (switch_theme)
// ============================================================

if ( ! function_exists( 'merkez_finans_theme_deactivate' ) ) :
	/**
	 * Tema degistirildiginde kurulum flag'ini temizle.
	 *
	 * @return void
	 */
	function merkez_finans_theme_deactivate(): void {
		// Sonraki kurulumda tekrar calissin isterseniz:
		// delete_option( 'merkez_finans_setup_done' );
	}
endif;
add_action( 'switch_theme', 'merkez_finans_theme_deactivate' );

// ============================================================
// 35. SERVICE META BOXES (Admin)
// ============================================================

if ( ! function_exists( 'merkez_finans_service_meta_boxes' ) ) :
	/**
	 * Hizmetler icin meta box ekle (Admin).
	 *
	 * @return void
	 */
	function merkez_finans_service_meta_boxes(): void {
		add_meta_box(
			'merkez_finans_service_details',
			__( 'Hizmet Detaylari', 'merkez-finans' ),
			'merkez_finans_service_meta_callback',
			'service',
			'normal',
			'high'
		);
	}
endif;
add_action( 'add_meta_boxes', 'merkez_finans_service_meta_boxes' );

if ( ! function_exists( 'merkez_finans_service_meta_callback' ) ) :
	/**
	 * Meta box icerigini render et.
	 *
	 * @param WP_Post $post Post nesnesi.
	 * @return void
	 */
	function merkez_finans_service_meta_callback( WP_Post $post ): void {
		wp_nonce_field( 'merkez_finans_service_save', 'merkez_finans_service_nonce' );

		$icon     = get_post_meta( $post->ID, '_service_icon_svg', true );
		$features = get_post_meta( $post->ID, '_service_features', true );
		$process  = get_post_meta( $post->ID, '_service_process', true );

		if ( ! is_array( $features ) ) {
			$features = array();
		}
		if ( ! is_array( $process ) ) {
			$process = array();
		}
		?>
		<style>
			.mf-meta-field { margin-bottom: 20px; }
			.mf-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; color: #1d2327; }
			.mf-meta-field .description { color: #646970; font-size: 12px; margin-top: 4px; font-style: italic; }
			.mf-meta-field textarea { width: 100%; font-family: monospace; font-size: 13px; }
			.mf-meta-field input[type="text"] { width: 100%; max-width: 600px; }
			.mf-repeater-item { display: flex; gap: 8px; margin-bottom: 8px; align-items: center; }
			.mf-repeater-item input { flex: 1; max-width: 500px; }
			.mf-repeater-item .button { flex-shrink: 0; }
			.mf-add-row { margin-top: 8px; }
		</style>

		<div class="mf-meta-field">
			<label for="_service_icon_svg"><?php esc_html_e( 'Font Awesome Ikonu', 'merkez-finans' ); ?></label>
			<select id="_service_icon_svg" name="_service_icon_svg" style="width:100%;max-width:500px;">
				<option value=""><?php esc_html_e( 'Varsayilan', 'merkez-finans' ); ?></option>
			<?php
			$fa_icons = array(
				'fa-calculator'         => 'Hesap Makinesi',
				'fa-file-invoice-dollar' => 'Fatura / Para',
				'fa-chart-line'         => 'Grafik / Analiz',
				'fa-chart-pie'          => 'Pasta Grafiği',
				'fa-chart-bar'          => 'Bar Grafiği',
				'fa-search'             => 'Arama / Denetim',
				'fa-building'           => 'Bina / Şirket',
				'fa-handshake'          => 'El Sıkışma',
				'fa-briefcase'          => 'Evrak Çantası',
				'fa-coins'              => 'Paralar',
				'fa-landmark'           => 'Banka / Kurum',
				'fa-balance-scale'      => 'Terazi / Adalet',
				'fa-users'              => 'Kullanıcılar / İK',
				'fa-globe'              => 'Dünya / Global',
				'fa-file-contract'      => 'Sözleşme',
				'fa-shield-halved'      => 'Kalkan / Güvenlik',
				'fa-wallet'             => 'Cüzdan',
				'fa-money-bill-wave'    => 'Para / Ödeme',
				'fa-percent'            => 'Yüzde / Vergi',
				'fa-gavel'              => 'Hakim / Hukuk',
			);
			foreach ( $fa_icons as $icon_class => $icon_label ) :
				$selected = ( $icon === '<i class="fas ' . $icon_class . '"></i>' ) ? 'selected' : '';
			?>
				<option value="<?php echo esc_attr( $icon_class ); ?>" <?php echo esc_attr( $selected ); ?>><?php echo esc_html( $icon_label ); ?> (<?php echo esc_html( $icon_class ); ?>)</option>
			<?php endforeach; ?>
			</select>
			<p class="description"><?php esc_html_e( 'Hizmet kartinda gorunecek Font Awesome ikonu. Bos birakilirsa varsayilan ikon kullanilir.', 'merkez-finans' ); ?></p>
		</div>

		<div class="mf-meta-field">
			<label><?php esc_html_e( 'Hizmet Ozellikleri', 'merkez-finans' ); ?></label>
			<div id="mf-features-repeater">
				<?php
				if ( empty( $features ) ) {
					$features = array( '' );
				}
				foreach ( $features as $feature ) :
				?>
					<div class="mf-repeater-item">
						<input type="text" name="_service_features[]" value="<?php echo esc_attr( $feature ); ?>" placeholder="<?php esc_attr_e( 'Orn: Mevzuata uygun vergi planlamasi', 'merkez-finans' ); ?>" />
						<button type="button" class="button mf-remove-row"><?php esc_html_e( 'Kaldir', 'merkez-finans' ); ?></button>
					</div>
				<?php endforeach; ?>
			</div>
			<button type="button" class="button mf-add-row" data-target="mf-features-repeater"><?php esc_html_e( '+ Ozellik Ekle', 'merkez-finans' ); ?></button>
			<p class="description"><?php esc_html_e( 'Hizmet detay sayfasinda liste halinde gorunecek ozellikler.', 'merkez-finans' ); ?></p>
		</div>

		<div class="mf-meta-field">
			<label><?php esc_html_e( 'Calisma Sureci Adimlari', 'merkez-finans' ); ?></label>
			<div id="mf-process-repeater">
				<?php
				if ( empty( $process ) ) {
					$process = array( '' );
				}
				foreach ( $process as $step ) :
				?>
					<div class="mf-repeater-item">
						<input type="text" name="_service_process[]" value="<?php echo esc_attr( $step ); ?>" placeholder="<?php esc_attr_e( 'Orn: Mevcut durum analizi', 'merkez-finans' ); ?>" />
						<button type="button" class="button mf-remove-row"><?php esc_html_e( 'Kaldir', 'merkez-finans' ); ?></button>
					</div>
				<?php endforeach; ?>
			</div>
			<button type="button" class="button mf-add-row" data-target="mf-process-repeater"><?php esc_html_e( '+ Adim Ekle', 'merkez-finans' ); ?></button>
			<p class="description"><?php esc_html_e( 'Hizmet detay sayfasinda numarali adimlar olarak gorunecek.', 'merkez-finans' ); ?></p>
		</div>

		<script>
		(function() {
			document.querySelectorAll('.mf-add-row').forEach(function(btn) {
				btn.addEventListener('click', function() {
					var target = document.getElementById(this.dataset.target);
					var item = target.querySelector('.mf-repeater-item').cloneNode(true);
					item.querySelector('input').value = '';
					target.appendChild(item);
				});
			});
			document.addEventListener('click', function(e) {
				if (e.target.classList.contains('mf-remove-row')) {
					var items = e.target.closest('[id*="repeater"]').querySelectorAll('.mf-repeater-item');
					if (items.length > 1) {
						e.target.closest('.mf-repeater-item').remove();
					} else {
						items[0].querySelector('input').value = '';
					}
				}
			});
		})();
		</script>
		<?php
	}
endif;

if ( ! function_exists( 'merkez_finans_service_save_meta' ) ) :
	/**
	 * Meta box verilerini kaydet.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	function merkez_finans_service_save_meta( int $post_id ): void {
		// Nonce dogrulama
		if ( ! isset( $_POST['merkez_finans_service_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['merkez_finans_service_nonce'] ) ), 'merkez_finans_service_save' ) ) {
			return;
		}

		// Auto-save kontrolu
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Yetki kontrolu
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Font Awesome Ikon
		if ( isset( $_POST['_service_icon_svg'] ) ) {
			$icon_class = sanitize_text_field( wp_unslash( $_POST['_service_icon_svg'] ) );
			if ( ! empty( $icon_class ) ) {
				update_post_meta( $post_id, '_service_icon_svg', '<i class="fas ' . esc_attr( $icon_class ) . '"></i>' );
			} else {
				delete_post_meta( $post_id, '_service_icon_svg' );
			}
		}

		// Ozellikler
		if ( isset( $_POST['_service_features'] ) && is_array( $_POST['_service_features'] ) ) {
			$features = array_filter( array_map( 'sanitize_text_field', wp_unslash( $_POST['_service_features'] ) ) );
			update_post_meta( $post_id, '_service_features', $features );
		} else {
			delete_post_meta( $post_id, '_service_features' );
		}

		// Surec adimlari
		if ( isset( $_POST['_service_process'] ) && is_array( $_POST['_service_process'] ) ) {
			$process = array_filter( array_map( 'sanitize_text_field', wp_unslash( $_POST['_service_process'] ) ) );
			update_post_meta( $post_id, '_service_process', $process );
		} else {
			delete_post_meta( $post_id, '_service_process' );
		}
	}
endif;
add_action( 'save_post', 'merkez_finans_service_save_meta' );

// ============================================================
// 36. THE END - functions.php
// ============================================================
