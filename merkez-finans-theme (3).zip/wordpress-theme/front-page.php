<?php
/**
 * Front Page Template
 *
 * Corporate landing page with all sections.
 * Hero | Services (CPT) | Why Us | Roadmap | Sectors | Stats | CTA | Blog | Contact
 *
 * @package Merkez_Finans
 * @version 1.0.0
 * @template full-width
 */

declare( strict_types=1 );

get_header();
?>

<!-- ============================================================
     A) HERO SECTION
     ============================================================ -->
<section class="hero-section" id="hero" aria-label="<?php esc_attr_e( 'Ana Banner', 'merkez-finans' ); ?>">

	<!-- Video Background -->
	<div class="hero-media">
		<?php
			$hero_video  = get_theme_mod( 'merkez_finans_hero_video', '' );
			$hero_poster = get_theme_mod( 'merkez_finans_hero_poster', '' );
			$poster_url  = $hero_poster ? $hero_poster : MERKEZ_FINANS_URI . '/assets/images/hero-poster.jpg';
			$use_video   = get_theme_mod( 'merkez_finans_hero_use_video', true );
			if ( $use_video && $hero_video ) :
			?>
			<video
				class="hero-video"
				autoplay
				muted
				loop
				playsinline
				poster="<?php echo esc_url( $poster_url ); ?>"
				aria-hidden="true"
			>
				<source src="<?php echo esc_url( $hero_video ); ?>" type="video/mp4">
			</video>
			<?php else : ?>
			<div class="hero-fallback-image" style="position:absolute;inset:0;background:url('<?php echo esc_url( $poster_url ); ?>') center/cover no-repeat;" aria-hidden="true"></div>
			<?php endif; ?>
		<div class="hero-overlay"></div>
		<div class="hero-fade-bottom"></div>
	</div>

	<!-- Hero Content -->
	<div class="container hero-content">
		<div class="hero-grid">

			<!-- Left: Text -->
			<div class="hero-text reveal">

				<!-- Badge -->
				<div class="hero-badge">
					<span class="badge-dot" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Kurumsal Finansal Çözüm Ortağınız', 'merkez-finans' ); ?></span>
				</div>

				<!-- H1 -->
				<h1 class="hero-title">
					<?php esc_html_e( 'Finansal Süreçlerinizi', 'merkez-finans' ); ?>
					<span class="text-accent"><?php esc_html_e( 'Güvenle', 'merkez-finans' ); ?></span>
					<?php esc_html_e( 'Yönetin', 'merkez-finans' ); ?>
				</h1>

				<!-- Subtitle -->
				<p class="hero-subtitle">
					<?php esc_html_e( 'Vergi, muhasebe, denetim ve finansal danışmanlık alanlarında işletmenize özel stratejik çözümler sunuyoruz.', 'merkez-finans' ); ?>
				</p>

				<!-- CTAs -->
				<div class="hero-ctas">
					<a href="#contact" class="btn btn-primary hero-cta-primary">
						<?php esc_html_e( 'Ücretsiz Danışmanlık Al', 'merkez-finans' ); ?>
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
					</a>
					<a href="#services" class="btn btn-secondary">
						<?php esc_html_e( 'Hizmetleri İncele', 'merkez-finans' ); ?>
					</a>
				</div>

				<!-- Trust Badges -->
				<div class="hero-trust">
					<div class="trust-item">
						<i class="fas fa-file-shield" aria-hidden="true"></i>
						<span><?php esc_html_e( 'Güncel Mevzuat', 'merkez-finans' ); ?></span>
					</div>
					<div class="trust-item">
						<i class="fas fa-shield-halved" aria-hidden="true"></i>
						<span><?php esc_html_e( 'Şeffaf Raporlama', 'merkez-finans' ); ?></span>
					</div>
					<div class="trust-item">
						<i class="fas fa-users" aria-hidden="true"></i>
						<span><?php esc_html_e( 'Uzman Ekip', 'merkez-finans' ); ?></span>
					</div>
					<div class="trust-item">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="2" width="16" height="20" rx="2" ry"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M12 10h.01"/><path d="M12 14h.01"/><path d="M16 10h.01"/><path d="M16 14h.01"/><path d="M8 10h.01"/><path d="M8 14h.01"/></svg>
						<span><?php esc_html_e( 'Kurumsal Çözüm', 'merkez-finans' ); ?></span>
					</div>
				</div>
			</div>

			<!-- Right: Floating Cards (Desktop only) -->
			<div class="hero-cards hide-mobile" aria-hidden="true">
				<div class="floating-card animate-float">
					<div class="floating-icon">
						<i class="fas fa-chevron-right"></i>
					</div>
					<span><?php esc_html_e( 'Vergi Danışmanlığı', 'merkez-finans' ); ?></span>
				</div>
				<div class="floating-card animate-float animate-float-delay-1">
					<div class="floating-icon">
						<i class="fas fa-chevron-right"></i>
					</div>
					<span><?php esc_html_e( 'Finansal Raporlama', 'merkez-finans' ); ?></span>
				</div>
				<div class="floating-card animate-float animate-float-delay-2">
					<div class="floating-icon">
						<i class="fas fa-chevron-right"></i>
					</div>
					<span><?php esc_html_e( 'Şirket Kuruluşu', 'merkez-finans' ); ?></span>
				</div>
				<div class="floating-card animate-float animate-float-delay-3">
					<div class="floating-icon">
						<i class="fas fa-chevron-right"></i>
					</div>
					<span><?php esc_html_e( 'Denetim & İç Kontrol', 'merkez-finans' ); ?></span>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- ============================================================
     B) SERVICES SECTION (Dynamic from Custom Post Type)
     ============================================================ -->
<section class="services-section section-padding" id="services" aria-labelledby="services-heading">
	<div class="container">

		<div class="section-header reveal">
			<span class="section-badge"><?php echo esc_html( get_theme_mod( 'merkez_finans_services_badge', __( 'Hizmetlerimiz', 'merkez-finans' ) ) ); ?></span>
			<h2 class="section-title" id="services-heading">
				<?php echo esc_html( get_theme_mod( 'merkez_finans_services_title_1', __( 'Isletmenize Ozel', 'merkez-finans' ) ) ); ?>
				<span class="text-gradient"><?php echo esc_html( get_theme_mod( 'merkez_finans_services_title_2', __( 'Finansal Cozumler', 'merkez-finans' ) ) ); ?></span>
			</h2>
			<p class="section-description">
				<?php echo esc_html( get_theme_mod( 'merkez_finans_services_desc', __( 'Vergiden finansmana, denetimden kurumsal danismanliga kadar tum ihtiyaclariniz icin yaninizdayiz.', 'merkez-finans' ) ) ); ?>
			</p>
		</div>

		<?php
		$sv_display_mode = get_theme_mod( 'merkez_finans_services_display_mode', 'auto' );
		$sv_count        = absint( get_theme_mod( 'merkez_finans_services_count', 8 ) );

		if ( 'manual' === $sv_display_mode ) {
			$sv_manual_ids = get_theme_mod( 'merkez_finans_services_manual_ids', '' );
			$sv_ids        = array_filter( array_map( 'intval', explode( ',', $sv_manual_ids ) ) );
			if ( ! empty( $sv_ids ) ) {
				$sv_args = array(
					'post_type'      => 'service',
					'post__in'       => $sv_ids,
					'orderby'        => 'post__in',
					'posts_per_page' => count( $sv_ids ),
				);
			} else {
				$sv_args = array(
					'post_type'      => 'service',
					'posts_per_page' => $sv_count,
					'orderby'        => 'date',
					'order'          => 'DESC',
				);
			}
		} else {
			$sv_args = array(
				'post_type'      => 'service',
				'posts_per_page' => $sv_count,
				'orderby'        => 'date',
				'order'          => 'DESC',
			);
		}

		$services_query = new WP_Query( $sv_args );

		if ( $services_query->have_posts() ) :
		?>
			<div class="services-grid">
				<?php
				$index = 0;
				while ( $services_query->have_posts() ) :
					$services_query->the_post();
					$delay      = $index * 75;
					$sv_icon    = get_post_meta( get_the_ID(), '_service_icon_svg', true );
					$sv_excerpt = get_the_excerpt();
					if ( empty( $sv_icon ) ) {
						$sv_icon = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>';
					}
				?>
					<div class="card service-card reveal" style="transition-delay: <?php echo esc_attr( $delay ); ?>ms;">
						<div class="card-icon">
							<?php echo wp_kses_post( $sv_icon ); ?>
						</div>
						<h3 class="card-title"><?php the_title(); ?></h3>
						<p class="card-text"><?php echo esc_html( $sv_excerpt ); ?></p>
						<a href="<?php the_permalink(); ?>" class="card-link">
							<?php esc_html_e( 'Detayli Incele', 'merkez-finans' ); ?>
							<i class="fas fa-arrow-right" aria-hidden="true"></i>
						</a>
					</div>
				<?php
				$index++;
				endwhile;
				wp_reset_postdata();
				?>
			</div>

			<div class="services-footer reveal" style="text-align: center; margin-top: 48px;">
				<a href="<?php echo esc_url( get_post_type_archive_link( 'service' ) ); ?>" class="btn btn-outline">
					<?php echo esc_html( get_theme_mod( 'merkez_finans_services_btn_text', __( 'Tum Hizmetleri Incele', 'merkez-finans' ) ) ); ?>
					<i class="fas fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>

		<?php else : ?>

			<div class="no-results reveal" style="text-align: center; padding: 64px 0;">
				<div class="no-results-icon" style="margin-bottom: 24px;">
					<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
				</div>
				<h3 style="font-size: var(--text-xl); color: var(--color-navy-800); margin-bottom: 12px;"><?php esc_html_e( 'Henüz hizmet eklenmemis.', 'merkez-finans' ); ?></h3>
				<p style="color: var(--color-text-muted);"><?php esc_html_e( 'Yakinda hizmetlerimiz eklenecek.', 'merkez-finans' ); ?></p>
			</div>

		<?php endif; ?>
	</div>
</section>


<!-- ============================================================
     C) WHY US SECTION
     ============================================================ -->
<section class="why-section section-padding" id="about" aria-labelledby="why-heading">
	<div class="container">
		<div class="why-grid">

			<!-- Left: Image -->
			<div class="why-image-wrapper reveal">
				<div class="why-image">
					<img
						src="<?php echo esc_url( MERKEZ_FINANS_URI . '/assets/images/about-team.jpg' ); ?>"
						alt="<?php esc_attr_e( 'Merkez Finansal Danışmanlık ekibi modern ofiste toplantı yapıyor', 'merkez-finans' ); ?>"
						loading="lazy"
					>
					<div class="why-image-overlay"></div>
				</div>
				<div class="why-stats-card">
					<div class="stats-icon">
						<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
					</div>
					<div class="stats-text">
						<span class="stats-number">%100</span>
						<span class="stats-label"><?php esc_html_e( 'Müşteri Memnuniyeti', 'merkez-finans' ); ?></span>
					</div>
				</div>
			</div>

			<!-- Right: Content -->
			<div class="why-content reveal">
				<span class="section-badge"><?php esc_html_e( 'Neden Biz', 'merkez-finans' ); ?></span>
				<h2 class="section-title" id="why-heading">
					<?php esc_html_e( 'İşletmenizin Finansal Güvenliği İçin', 'merkez-finans' ); ?>
					<span class="text-gradient"><?php esc_html_e( 'Doğru Partner', 'merkez-finans' ); ?></span>
				</h2>
				<p class="section-description">
					<?php esc_html_e( 'Deneyimli ekibimiz ve teknolojik altyapımızla, işletmenizin finansal süreçlerini en verimli şekilde yönetiyoruz.', 'merkez-finans' ); ?>
				</p>

				<div class="why-features">
					<?php
					$features = array(
						array(
							'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
							'title' => __( 'Güncel Mevzuata Tam Uyum', 'merkez-finans' ),
							'desc'  => __( 'Sürekli güncellenen mevzuat takibi ile yasal risklerinizi sıfıra indirin.', 'merkez-finans' ),
						),
						array(
							'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
							'title' => __( 'Şeffaf ve Anlaşılır Raporlama', 'merkez-finans' ),
							'desc'  => __( 'Karmaşık verileri sade ve anlaşılır raporlarla sunuyoruz.', 'merkez-finans' ),
						),
						array(
							'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/></svg>',
							'title' => __( 'Dijital Süreç Yönetimi', 'merkez-finans' ),
							'desc'  => __( 'Modern yazılımlar ve otomasyon ile hızlı ve hatasız iş süreçleri.', 'merkez-finans' ),
						),
						array(
							'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
							'title' => __( 'Hızlı Geri Dönüş', 'merkez-finans' ),
							'desc'  => __( 'Sorularınıza ve taleplerinize en kısa sürede yanıt veriyoruz.', 'merkez-finans' ),
						),
						array(
							'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
							'title' => __( 'Sektörel Uzmanlık', 'merkez-finans' ),
							'desc'  => __( 'Farklı sektörlerdeki deneyimimizle özel çözümler üretiyoruz.', 'merkez-finans' ),
						),
						array(
							'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
							'title' => __( 'İşletmeye Özel Yaklaşım', 'merkez-finans' ),
							'desc'  => __( 'Her işletmenin benzersiz olduğunu bilerek özel stratejiler geliştiriyoruz.', 'merkez-finans' ),
						),
					);

					foreach ( $features as $feature ) :
					?>
						<div class="why-feature">
							<div class="why-feature-icon">
								<?php echo wp_kses_post( $feature['icon'] ); ?>
							</div>
							<div class="why-feature-text">
								<h4><?php echo esc_html( $feature['title'] ); ?></h4>
								<p><?php echo esc_html( $feature['desc'] ); ?></p>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- ============================================================
     D) ROADMAP / WORKING MODEL SECTION
     ============================================================ -->
<section class="roadmap-section section-padding" id="process" aria-labelledby="roadmap-heading">
	<div class="container">

		<div class="section-header reveal">
			<span class="section-badge"><?php echo esc_html( get_theme_mod( 'merkez_finans_roadmap_badge', __( 'ÇALIŞMA MODELİMİZ', 'merkez-finans' ) ) ); ?></span>
			<h2 class="section-title" id="roadmap-heading">
				<?php echo esc_html( get_theme_mod( 'merkez_finans_roadmap_title', __( '4 Adımda Finansal Yol Haritanız', 'merkez-finans' ) ) ); ?>
			</h2>
			<p class="section-description">
				<?php echo esc_html( get_theme_mod( 'merkez_finans_roadmap_desc', __( 'Dört aşamalı mükemmellik modelimizle başarıyı garantiliyoruz.', 'merkez-finans' ) ) ); ?>
			</p>
		</div>

		<div class="roadmap-timeline">
			<!-- Connecting Line -->
			<div class="roadmap-line" aria-hidden="true"></div>

			<?php
			$roadmap_steps = array(
				array(
					'number' => '1',
					'icon'   => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>',
					'default_title'  => __( 'İhtiyaç Analizi', 'merkez-finans' ),
					'default_desc'   => __( 'Mevcut mali tablo ve süreçlerinizi inceler, hedeflerinizi netleştiririz.', 'merkez-finans' ),
				),
				array(
					'number' => '2',
					'icon'   => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>',
					'default_title'  => __( 'Strateji ve Planlama', 'merkez-finans' ),
					'default_desc'   => __( 'Vergi, raporlama ve nakit akışı için özel yol haritası kurarız.', 'merkez-finans' ),
				),
				array(
					'number' => '3',
					'icon'   => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
					'default_title'  => __( 'Uygulama', 'merkez-finans' ),
					'default_desc'   => __( 'Operasyonu üstlenir, mevzuata uygun şekilde yürütürüz.', 'merkez-finans' ),
				),
				array(
					'number' => '4',
					'icon'   => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/><polyline points="7 10 12 15 17 10"/><polyline points="7 6 12 11 17 6"/></svg>',
					'default_title'  => __( 'Raporlama', 'merkez-finans' ),
					'default_desc'   => __( 'Sonuçları periyodik olarak şeffaf raporlarla sunuyoruz.', 'merkez-finans' ),
				),
			);

			foreach ( $roadmap_steps as $index => $step ) :
				$step_title = get_theme_mod( "merkez_finans_roadmap_step_{$index}_title", $step['default_title'] );
				$step_desc  = get_theme_mod( "merkez_finans_roadmap_step_{$index}_desc", $step['default_desc'] );
				$step_icon  = get_theme_mod( "merkez_finans_roadmap_step_{$index}_icon", '' );
				$delay      = $index * 150;

				// Kullanıcı özel ikon eklemediyse varsayılan ikonu kullan.
				$icon_html = $step_icon ? wp_kses_post( $step_icon ) : $step['icon'];
			?>
				<div class="roadmap-step reveal" style="transition-delay: <?php echo esc_attr( $delay ); ?>ms;" data-step="<?php echo esc_attr( $step['number'] ); ?>">
					<div class="roadmap-circle">
						<div class="roadmap-icon">
							<?php echo wp_kses_post( $icon_html ); ?>
						</div>
					</div>
					<div class="roadmap-content">
						<h3 class="roadmap-step-title">
							<span class="roadmap-number"><?php echo esc_html( $step['number'] ); ?>.</span>
							<?php echo esc_html( $step_title ); ?>
						</h3>
						<p class="roadmap-step-desc"><?php echo esc_html( $step_desc ); ?></p>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>


<!-- ============================================================
     E) SECTORS SECTION
     ============================================================ -->
<section class="sectors-section section-padding" id="sectors" aria-labelledby="sectors-heading">
	<div class="container">

		<div class="section-header reveal">
			<span class="section-badge"><?php echo esc_html( get_theme_mod( 'merkez_finans_sectors_badge', 'Sektorel Cozumler' ) ); ?></span>
			<h2 class="section-title" id="sectors-heading">
				<?php echo esc_html( get_theme_mod( 'merkez_finans_sectors_title', 'Sektorunuze Ozel' ) ); ?>
				<span class="text-gradient"><?php echo esc_html( get_theme_mod( 'merkez_finans_sectors_title_gradient', 'Uzmanlik' ) ); ?></span>
			</h2>
			<p class="section-description">
				<?php echo esc_html( get_theme_mod( 'merkez_finans_sectors_desc', 'Her sektorun farkli dinamiklerini bilerek, ozel cozumler uretiyoruz.' ) ); ?>
			</p>
		</div>

		<div class="sectors-grid">
			<?php
			$sectors = array(
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 00-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 012-3.95A12.88 12.88 0 0122 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 01-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>',
					'title' => __( 'Start-up ve Girişimciler', 'merkez-finans' ),
					'desc'  => __( 'Yeni kurulan işletmeler için finansal altyapı, vergi planlaması ve yatırımcı raporlama hizmetleri.', 'merkez-finans' ),
				),
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
					'title' => __( 'KOBİ\'ler', 'merkez-finans' ),
					'desc'  => __( 'Küçük ve orta ölçekli işletmelere özel maliyet etkin muhasebe ve finansal yönetim çözümleri.', 'merkez-finans' ),
				),
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg>',
					'title' => __( 'E-Ticaret İşletmeleri', 'merkez-finans' ),
					'desc'  => __( 'Online satış platformları için özel vergi düzenlemeleri ve finansal raporlama hizmetleri.', 'merkez-finans' ),
				),
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12h20"/><path d="M20 12v8a2 2 0 01-2 2H6a2 2 0 01-2-2v-8"/><path d="M12 2v10"/><path d="M8 6l4-4 4 4"/></svg>',
					'title' => __( 'Yurt Dışı İşlem Yapan Firmalar', 'merkez-finans' ),
					'desc'  => __( 'Uluslararası ticaret, transfer fiyatlandırması ve çifte vergilendirme anlaşmaları danışmanlığı.', 'merkez-finans' ),
				),
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>',
					'title' => __( 'Hizmet Sektörü', 'merkez-finans' ),
					'desc'  => __( 'Danışmanlık, eğitim, sağlık ve diğer hizmet sektörlerine özel finansal çözümler.', 'merkez-finans' ),
				),
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 20a2.4 2.4 0 002.571-1.485l.1-.174A3 3 0 017.081 17h9.838a3 3 0 012.41 1.341l.1.174A2.4 2.4 0 0022 20"/><path d="M6.563 17A5.69 5.69 0 0110 14.5a5.69 5.69 0 013.437 2.5"/><path d="M6.296 7.893A6.003 6.003 0 0010 5"/><path d="M17.704 7.893A6.003 6.003 0 0114 5"/><path d="M12 2v3"/><path d="M12 14.5v-3"/><path d="M7 10h10"/></svg>',
					'title' => __( 'Üretim ve Ticaret Şirketleri', 'merkez-finans' ),
					'desc'  => __( 'Stok yönetiminden maliyet muhasebesine kadar üretim ve ticaret odaklı hizmetler.', 'merkez-finans' ),
				),
			);

			foreach ( $sectors as $index => $sector ) :
				$delay = $index * 100;
			?>
				<div class="sector-card reveal" style="transition-delay: <?php echo esc_attr( $delay ); ?>ms;">
					<div class="sector-icon-wrapper">
						<?php $s_icon = get_theme_mod( "merkez_finans_sector_{$index}_icon", 'fa-building' );
							echo '<i class="fas ' . esc_attr( $s_icon ) . '"></i>'; ?>
					</div>

					<h3 class="sector-title"><?php echo esc_html( get_theme_mod( "merkez_finans_sector_{$index}_title", $sector['title'] ) ); ?></h3>
					<p class="sector-desc"><?php echo esc_html( merkez_finans_trim_text( get_theme_mod( "merkez_finans_sector_{$index}_desc", $sector['desc'] ), 140 ) ); ?></p>
					<a href="#" class="sector-link">
						<?php esc_html_e( 'Çözümleri İncele', 'merkez-finans' ); ?>
						<i class="fas fa-arrow-right" aria-hidden="true"></i>
					</a>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>


<!-- ============================================================
     F) STATS / COUNTER SECTION
     ============================================================ -->
<section class="stats-section" id="stats" aria-label="<?php esc_attr_e( 'İstatistikler', 'merkez-finans' ); ?>">
	<div class="stats-bg" aria-hidden="true"></div>
	<div class="container">
		<div class="stats-grid">
			<?php
			$stats = array(
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
					'value' => '10',
					'suffix' => '+',
					'label' => __( 'Yıl Deneyim', 'merkez-finans' ),
					'desc'  => __( 'Sektör tecrübesi', 'merkez-finans' ),
				),
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
					'value' => '250',
					'suffix' => '+',
					'label' => __( 'Danışmanlık Süreci', 'merkez-finans' ),
					'desc'  => __( 'Başarılı proje', 'merkez-finans' ),
				),
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
					'value' => '20',
					'suffix' => '+',
					'label' => __( 'Hizmet Alanı', 'merkez-finans' ),
					'desc'  => __( 'Kapsamlı çözüm', 'merkez-finans' ),
				),
				array(
					'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>',
					'value' => '100',
					'suffix' => '%',
					'label' => __( 'Mevzuat Odaklı', 'merkez-finans' ),
					'desc'  => __( 'Yasal uyum', 'merkez-finans' ),
				),
			);

			foreach ( $stats as $index => $stat ) :
				$delay = $index * 150;
			?>
				<div class="stat-item reveal" style="transition-delay: <?php echo esc_attr( $delay ); ?>ms;" data-count="<?php echo esc_attr( $stat['value'] ); ?>">
					<div class="stat-icon"><?php echo wp_kses_post( $stat['icon'] ); ?></div>
					<div class="stat-value">
						<span class="stat-number" data-target="<?php echo esc_attr( $stat['value'] ); ?>">0</span>
						<span class="stat-suffix"><?php echo esc_html( $stat['suffix'] ); ?></span>
					</div>
					<div class="stat-label"><?php echo esc_html( $stat['label'] ); ?></div>
					<div class="stat-desc"><?php echo esc_html( $stat['desc'] ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>


<!-- ============================================================
     G) CTA SECTION
     ============================================================ -->
<section class="cta-section" id="cta" aria-label="<?php esc_attr_e( 'Eylem Çağrısı', 'merkez-finans' ); ?>">
	<div class="cta-bg" aria-hidden="true"></div>
	<div class="container">
		<div class="cta-content reveal">
			<div class="cta-badge">
				<i class="fas fa-play" aria-hidden="true"></i>
				<span><?php esc_html_e( 'Hemen Başlayın', 'merkez-finans' ); ?></span>
			</div>
			<h2 class="cta-title">
				<?php esc_html_e( 'Finansal Süreçlerinizi Bugünden Güvence Altına Alın', 'merkez-finans' ); ?>
			</h2>
			<p class="cta-desc">
				<?php esc_html_e( 'Ücretsiz ilk görüşmemizde işletmenizin finansal ihtiyaçlarını analiz edelim ve size özel bir yol haritası oluşturalım.', 'merkez-finans' ); ?>
			</p>
			<div class="cta-buttons">
				<a href="#contact" class="btn btn-white cta-btn-primary">
					<?php esc_html_e( 'Uzmanla Görüşme Planla', 'merkez-finans' ); ?>
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
				</a>
				<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', merkez_finans_get_contact( 'phone' ) ) ); ?>" class="btn btn-outline cta-btn-secondary">
					<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
					<?php echo esc_html( merkez_finans_get_contact( 'phone' ) ); ?>
				</a>
			</div>
		</div>
	</div>
</section>


<!-- ============================================================
     H) BLOG SECTION (Front Page Preview)
     ============================================================ -->
<section class="blog-section section-padding" id="blog" aria-labelledby="blog-heading">
	<div class="container">

		<div class="section-header reveal">
			<span class="section-badge"><?php echo esc_html( get_theme_mod( 'merkez_finans_blog_badge', __( 'Blog & Bilgilendirme', 'merkez-finans' ) ) ); ?></span>
			<h2 class="section-title" id="blog-heading">
				<?php echo esc_html( get_theme_mod( 'merkez_finans_blog_title', __( 'Guncel', 'merkez-finans' ) ) ); ?>
				<span class="text-gradient"><?php echo esc_html( get_theme_mod( 'merkez_finans_blog_title_gradient', __( 'Bilgiler', 'merkez-finans' ) ) ); ?></span>
				<?php echo esc_html( get_theme_mod( 'merkez_finans_blog_title_suffix', __( 've Rehberler', 'merkez-finans' ) ) ); ?>
			</h2>
		</div>

		<?php
		// Blog display mode: auto = latest posts, manual = selected posts
		$display_mode = get_theme_mod( 'merkez_finans_blog_display_mode', 'auto' );
		$post_count   = absint( get_theme_mod( 'merkez_finans_blog_post_count', 3 ) );

		if ( 'manual' === $display_mode ) {
			// Manuel mode: virgulle ayrilmis post ID'lerini al
			$manual_ids = get_theme_mod( 'merkez_finans_blog_manual_posts', '' );
			$post_ids   = array_filter( array_map( 'intval', explode( ',', $manual_ids ) ) );

			if ( ! empty( $post_ids ) ) {
				$blog_args = array(
					'post_type'      => 'post',
					'post__in'       => $post_ids,
					'orderby'        => 'post__in',
					'posts_per_page' => count( $post_ids ),
				);
			} else {
				// ID'ler bos ise fallback olarak otomatik mod
				$blog_args = array(
					'post_type'      => 'post',
					'posts_per_page' => $post_count,
					'orderby'        => 'date',
					'order'          => 'DESC',
				);
			}
		} else {
			// Otomatik mode: son yazilar
			$blog_args = array(
				'post_type'      => 'post',
				'posts_per_page' => $post_count,
				'orderby'        => 'date',
				'order'          => 'DESC',
			);
		}

		$blog_query = new WP_Query( $blog_args );

		if ( $blog_query->have_posts() ) :
		?>
			<div class="blog-preview-grid">
				<?php
				while ( $blog_query->have_posts() ) :
					$blog_query->the_post();
					$category = get_the_category();
				?>
					<article class="blog-preview-card reveal">
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="blog-preview-image">
								<a href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
									<?php the_post_thumbnail( 'merkez-finans-blog', array( 'alt' => the_title_attribute( array( 'echo' => false ) ), 'loading' => 'lazy' ) ); ?>
								</a>
								<div class="blog-preview-overlay"></div>
								<?php if ( ! empty( $category ) ) : ?>
									<span class="blog-preview-category"><?php echo esc_html( $category[0]->name ); ?></span>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<div class="blog-preview-content">
							<div class="blog-preview-meta">
								<span>
									<i class="far fa-calendar" aria-hidden="true"></i>
									<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
								</span>
								<span>
									<i class="far fa-clock" aria-hidden="true"></i>
									<?php echo esc_html( merkez_finans_reading_time() ); ?>
								</span>
							</div>

							<h3 class="blog-preview-title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h3>

							<p class="blog-preview-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>

							<a href="<?php the_permalink(); ?>" class="blog-preview-read-more">
								<?php esc_html_e( 'Devamını Oku', 'merkez-finans' ); ?>
								<i class="fas fa-arrow-right" aria-hidden="true"></i>
							</a>
						</div>
					</article>
				<?php endwhile; ?>
			</div>

			<div class="blog-preview-footer reveal">
				<a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ? get_permalink( get_option( 'page_for_posts' ) ) : get_post_type_archive_link( 'post' ) ); ?>" class="btn btn-outline">
					<?php esc_html_e( 'Tüm Yazıları Gör', 'merkez-finans' ); ?>
					<i class="fas fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>

			<?php wp_reset_postdata(); ?>

		<?php else : ?>

			<div class="no-results reveal">
				<p><?php esc_html_e( 'Henüz blog yazısı bulunmuyor.', 'merkez-finans' ); ?></p>
			</div>

		<?php endif; ?>
	</div>
</section>


<!-- ============================================================
     I) CONTACT SECTION
     ============================================================ -->
<section class="contact-section section-padding" id="contact" aria-labelledby="contact-heading">
	<div class="container">
		<div class="contact-grid">

			<!-- Left: Contact Info -->
			<div class="contact-info reveal">
				<span class="section-badge"><?php esc_html_e( 'İletişim', 'merkez-finans' ); ?></span>
				<h2 class="section-title" id="contact-heading">
					<?php esc_html_e( 'Bize', 'merkez-finans' ); ?>
					<span class="text-gradient"><?php esc_html_e( 'Ulaşın', 'merkez-finans' ); ?></span>
				</h2>
				<p class="section-description">
					<?php esc_html_e( 'Finansal danışmanlık ihtiyaçlarınız için formu doldurun, uzman ekibimiz en kısa sürede size dönsün.', 'merkez-finans' ); ?>
				</p>

				<div class="contact-details">
					<div class="contact-detail">
						<div class="contact-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
						</div>
						<div>
							<strong><?php esc_html_e( 'Telefon', 'merkez-finans' ); ?></strong>
							<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', merkez_finans_get_contact( 'phone' ) ) ); ?>"><?php echo esc_html( merkez_finans_get_contact( 'phone' ) ); ?></a>
						</div>
					</div>

					<div class="contact-detail">
						<div class="contact-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
						</div>
						<div>
							<strong><?php esc_html_e( 'E-posta', 'merkez-finans' ); ?></strong>
							<a href="mailto:<?php echo esc_attr( merkez_finans_get_contact( 'email' ) ); ?>"><?php echo esc_html( merkez_finans_get_contact( 'email' ) ); ?></a>
						</div>
					</div>

					<div class="contact-detail">
						<div class="contact-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
						</div>
						<div>
							<strong><?php esc_html_e( 'Adres', 'merkez-finans' ); ?></strong>
							<span><?php echo nl2br( esc_html( merkez_finans_get_contact( 'address' ) ) ); ?></span>
						</div>
					</div>

					<div class="contact-detail">
						<div class="contact-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
						</div>
						<div>
							<strong><?php esc_html_e( 'Çalışma Saatleri', 'merkez-finans' ); ?></strong>
							<span><?php echo esc_html( merkez_finans_get_contact( 'working_hours' ) ); ?></span>
						</div>
					</div>
				</div>
			</div>

			<!-- Right: Contact Form -->
			<div class="contact-form-wrapper reveal">
				<?php echo do_shortcode( '[contact_form]' ); ?>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
