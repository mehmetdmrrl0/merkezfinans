<?php
/**
 * Comments Template
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>

		<h3 class="comments-title">
			<?php
			$comment_count = get_comments_number();
			if ( '1' === $comment_count ) {
				echo esc_html_e( '1 Yorum', 'merkez-finans' );
			} else {
				printf(
					esc_html( _n( '%s Yorum', '%s Yorum', $comment_count, 'merkez-finans' ) ),
					number_format_i18n( $comment_count )
				);
			}
			?>
		</h3>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 48,
					'callback'    => 'merkez_finans_comment_template',
				)
			);
			?>
		</ol>

		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
			<nav class="comment-navigation" role="navigation">
				<div class="nav-previous"><?php previous_comments_link( esc_html__( 'Önceki Yorumlar', 'merkez-finans' ) ); ?></div>
				<div class="nav-next"><?php next_comments_link( esc_html__( 'Sonraki Yorumlar', 'merkez-finans' ) ); ?></div>
			</nav>
		<?php endif; ?>

	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="no-comments"><?php esc_html_e( 'Yorumlar kapalı.', 'merkez-finans' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'title_reply'          => esc_html__( 'Yorum Yapın', 'merkez-finans' ),
			'title_reply_to'       => esc_html__( '%s Yanıtla', 'merkez-finans' ),
			'cancel_reply_link'    => esc_html__( 'İptal', 'merkez-finans' ),
			'label_submit'         => esc_html__( 'Gönder', 'merkez-finans' ),
			'class_submit'         => 'btn btn-primary',
			'comment_field'        => '<div class="form-group"><label for="comment">' . esc_html__( 'Yorumunuz', 'merkez-finans' ) . ' *</label><textarea id="comment" name="comment" class="form-control" rows="5" required></textarea></div>',
			'fields'               => apply_filters(
				'comment_form_default_fields',
				array(
					'author' => '<div class="form-row"><div class="form-group"><label for="author">' . esc_html__( 'Adınız', 'merkez-finans' ) . ' *</label><input id="author" name="author" type="text" class="form-control" required></div>',
					'email'  => '<div class="form-group"><label for="email">' . esc_html__( 'E-posta', 'merkez-finans' ) . ' *</label><input id="email" name="email" type="email" class="form-control" required></div></div>',
					'url'    => '',
				)
			),
			'comment_notes_before' => '<p class="comment-notes" style="font-size: var(--text-sm); color: var(--color-text-muted); margin-bottom: 20px;">' . esc_html__( 'E-posta adresiniz yayınlanmayacak. Gerekli alanlar işaretlenmiştir.', 'merkez-finans' ) . '</p>',
		)
	);
	?>

</div>
