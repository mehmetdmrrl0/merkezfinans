<?php
/**
 * Default Page Template
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();

while ( have_posts() ) :
	the_post();
?>

<!-- Page Header -->
<section class="page-header" style="background: var(--gradient-navy);">
	<div class="container">
		<h1 class="page-title"><?php the_title(); ?></h1>
		<?php echo wp_kses_post( merkez_finans_breadcrumbs() ); ?>
	</div>
</section>

<!-- Page Content -->
<section class="section-padding">
	<div class="container" style="max-width: 800px;">
		<div class="entry-content" style="font-size: var(--text-lg); line-height: 1.8;">
			<?php the_content(); ?>
		</div>
	</div>
</section>

<?php
endwhile;
get_footer();
