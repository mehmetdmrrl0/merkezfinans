<?php
/**
 * Custom Navigation Walker
 *
 * Extends WordPress Walker_Nav_Menu for the theme's custom menu markup.
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

if ( ! class_exists( 'Merkez_Finans_Nav_Walker' ) ) :

	/**
	 * Class Merkez_Finans_Nav_Walker
	 */
	class Merkez_Finans_Nav_Walker extends Walker_Nav_Menu {

		/**
		 * Starts the element output.
		 *
		 * @param string   $output            Passed by reference. Used to append additional content.
		 * @param WP_Post  $data_object       Menu item data object.
		 * @param int      $depth             Depth of menu item. Used for padding.
		 * @param stdClass $args              An object of wp_nav_menu() arguments.
		 * @param int      $current_object_id Optional. ID of the current menu item. Default 0.
		 * @return void
		 */
		public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ): void {

			$menu_item = $data_object;

			$classes   = empty( $menu_item->classes ) ? array() : (array) $menu_item->classes;
			$classes[] = 'menu-item-' . $menu_item->ID;
			$classes[] = 'nav-item';

			if ( in_array( 'menu-item-has-children', $classes, true ) ) {
				$classes[] = 'has-dropdown';
			}

			if ( in_array( 'current-menu-item', $classes, true ) || in_array( 'current-menu-parent', $classes, true ) ) {
				$classes[] = 'is-active';
			}

			$class_names = implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $menu_item, $args, $depth ) );
			$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

			$id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $menu_item->ID, $menu_item, $args, $depth );
			$id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

			$output .= '<li' . $id . $class_names . '>';

			$atts = array();
			$atts['title']  = ! empty( $menu_item->attr_title ) ? $menu_item->attr_title : '';
			$atts['target'] = ! empty( $menu_item->target ) ? $menu_item->target : '';
			$atts['rel']    = ! empty( $menu_item->xfn ) ? $menu_item->xfn : '';
			$atts['href']   = ! empty( $menu_item->url ) ? $menu_item->url : '';
			$atts['class']  = 'nav-link';

			if ( in_array( 'menu-item-has-children', $classes, true ) ) {
				$atts['aria-haspopup']  = 'true';
				$atts['aria-expanded']  = 'false';
			}

			$atts = apply_filters( 'nav_menu_link_attributes', $atts, $menu_item, $args, $depth );

			$attributes = '';
			foreach ( $atts as $attr => $value ) {
				if ( is_scalar( $value ) && '' !== $value && false !== $value ) {
					$value       = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
					$attributes .= ' ' . $attr . '="' . $value . '"';
				}
			}

			$title = apply_filters( 'the_title', $menu_item->title, $menu_item->ID );
			$title = apply_filters( 'nav_menu_item_title', $title, $menu_item, $args, $depth );

			$item_output  = $args->before ?? '';
			$item_output .= '<a' . $attributes . '>';
			$item_output .= $args->link_before ?? '';
			$item_output .= $title;
			$item_output .= $args->link_after ?? '';

			if ( in_array( 'menu-item-has-children', $classes, true ) ) {
				$item_output .= '<svg class="dropdown-icon" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>';
			}

			$item_output .= '</a>';
			$item_output .= $args->after ?? '';

			$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $menu_item, $depth, $args );
		}

		/**
		 * Starts the list before the elements are added.
		 *
		 * @param string   $output Passed by reference. Used to append additional content.
		 * @param int      $depth  Depth of menu item. Used for padding.
		 * @param stdClass $args   An object of wp_nav_menu() arguments.
		 * @return void
		 */
		public function start_lvl( &$output, $depth = 0, $args = null ): void {

			$indent  = str_repeat( "\t", $depth );
			$output .= "\n$indent<ul class=\"sub-menu\">\n";
		}

		/**
		 * Ends the list of after the elements are added.
		 *
		 * @param string   $output Passed by reference. Used to append additional content.
		 * @param int      $depth  Depth of menu item. Used for padding.
		 * @param stdClass $args   An object of wp_nav_menu() arguments.
		 * @return void
		 */
		public function end_lvl( &$output, $depth = 0, $args = null ): void {

			$indent  = str_repeat( "\t", $depth );
			$output .= "$indent</ul>\n";
		}
	}

endif;
