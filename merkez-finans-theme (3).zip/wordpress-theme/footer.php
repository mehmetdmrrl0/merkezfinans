<?php
/**
 * Theme Footer Template
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

?>
</main><!-- #primary-content -->

<!-- ==================== FOOTER ==================== -->
<footer class="site-footer" role="contentinfo">
	<div class="container">
		<div class="footer-grid">

			<!-- Footer Column 1: Branding + Description + Social -->
			<div class="footer-col footer-col-brand">
				<div class="footer-brand">
					<?php if ( has_custom_logo() ) : ?>
						<div class="footer-logo"><?php the_custom_logo(); ?></div>
					<?php else : ?>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-logo-link" rel="home">
							<div class="logo-box">
								<span class="logo-letter">M</span>
							</div>
							<div class="logo-text">
								<span class="logo-title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
								<span class="logo-tagline"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></span>
							</div>
						</a>
					<?php endif; ?>
				</div>

				<p class="footer-description">
					<?php esc_html_e( 'Vergi, muhasebe, denetim ve finansal danışmanlık alanlarında işletmenize özel çözümler sunuyoruz.', 'merkez-finans' ); ?>
				</p>

				<!-- Social Media Icons -->
				<div class="footer-social">
					<?php
					$social_networks = array(
						'linkedin'  => array(
							'label' => __( 'LinkedIn', 'merkez-finans' ),
							'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>',
						),
						'twitter'   => array(
							'label' => __( 'Twitter', 'merkez-finans' ),
							'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>',
						),
						'facebook'  => array(
							'label' => __( 'Facebook', 'merkez-finans' ),
							'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>',
						),
						'instagram' => array(
							'label' => __( 'Instagram', 'merkez-finans' ),
							'icon'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>',
						),
					);

					foreach ( $social_networks as $slug => $network ) :
						$url = merkez_finans_get_social( $slug );
						if ( ! empty( $url ) ) :
						?>
							<a
								href="<?php echo esc_url( $url ); ?>"
								target="_blank"
								rel="noopener noreferrer"
								class="social-icon"
								aria-label="<?php echo esc_attr( $network['label'] ); ?>"
							>
								<?php echo wp_kses_post( $network['icon'] ); ?>
							</a>
						<?php
						endif;
					endforeach;
					?>
				</div>
			</div>

			<!-- Footer Column 2: Services -->
			<div class="footer-col">
				<h4 class="footer-heading"><?php esc_html_e( 'Hizmetlerimiz', 'merkez-finans' ); ?></h4>
				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<?php dynamic_sidebar( 'footer-1' ); ?>
				<?php else : ?>
					<ul class="footer-links">
						<li><a href="#services"><?php esc_html_e( 'Muhasebe ve Vergi Çözümleri', 'merkez-finans' ); ?></a></li>
						<li><a href="#services"><?php esc_html_e( 'Vergi Danışmanlığı', 'merkez-finans' ); ?></a></li>
						<li><a href="#services"><?php esc_html_e( 'Finansal Raporlama', 'merkez-finans' ); ?></a></li>
						<li><a href="#services"><?php esc_html_e( 'Denetim Hizmetleri', 'merkez-finans' ); ?></a></li>
						<li><a href="#services"><?php esc_html_e( 'Şirket Kuruluşu', 'merkez-finans' ); ?></a></li>
						<li><a href="#services"><?php esc_html_e( 'Bordro Yönetimi', 'merkez-finans' ); ?></a></li>
					</ul>
				<?php endif; ?>
			</div>

			<!-- Footer Column 3: Corporate -->
			<div class="footer-col">
				<h4 class="footer-heading"><?php esc_html_e( 'Kurumsal', 'merkez-finans' ); ?></h4>
				<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
					<?php dynamic_sidebar( 'footer-2' ); ?>
				<?php else : ?>
					<ul class="footer-links">
						<li><a href="#about"><?php esc_html_e( 'Hakkımızda', 'merkez-finans' ); ?></a></li>
						<li><a href="#services"><?php esc_html_e( 'Hizmetlerimiz', 'merkez-finans' ); ?></a></li>
						<li><a href="#sectors"><?php esc_html_e( 'Sektörel Çözümler', 'merkez-finans' ); ?></a></li>
						<li><a href="#blog"><?php esc_html_e( 'Blog', 'merkez-finans' ); ?></a></li>
						<li><a href="#"><?php esc_html_e( 'Kariyer', 'merkez-finans' ); ?></a></li>
						<li><a href="#contact"><?php esc_html_e( 'İletişim', 'merkez-finans' ); ?></a></li>
					</ul>
				<?php endif; ?>
			</div>

			<!-- Footer Column 4: Contact + Newsletter -->
			<div class="footer-col">
				<h4 class="footer-heading"><?php esc_html_e( 'İletişim', 'merkez-finans' ); ?></h4>
				<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
					<?php dynamic_sidebar( 'footer-3' ); ?>
				<?php else : ?>
					<ul class="footer-contact">
						<li class="contact-item">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
							<span><?php echo nl2br( esc_html( merkez_finans_get_contact( 'address' ) ) ); ?></span>
						</li>
						<li class="contact-item">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
							<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', merkez_finans_get_contact( 'phone' ) ) ); ?>"><?php echo esc_html( merkez_finans_get_contact( 'phone' ) ); ?></a>
						</li>
						<li class="contact-item">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
							<a href="mailto:<?php echo esc_attr( merkez_finans_get_contact( 'email' ) ); ?>"><?php echo esc_html( merkez_finans_get_contact( 'email' ) ); ?></a>
						</li>
					</ul>
				<?php endif; ?>

				<!-- Newsletter -->
				<div class="footer-newsletter">
					<h5 class="newsletter-heading"><?php esc_html_e( 'Bültenimize Abone Olun', 'merkez-finans' ); ?></h5>
					<form class="newsletter-form" id="newsletter-form" method="post">
						<?php wp_nonce_field( 'merkez_finans_newsletter', 'newsletter_nonce' ); ?>
						<div class="newsletter-field">
							<input
								type="email"
								name="subscriber_email"
								id="subscriber-email"
								placeholder="<?php esc_attr_e( 'E-posta adresiniz', 'merkez-finans' ); ?>"
								required
								class="newsletter-input"
								aria-label="<?php esc_attr_e( 'E-posta adresiniz', 'merkez-finans' ); ?>"
							>
							<button type="submit" class="newsletter-submit" aria-label="<?php esc_attr_e( 'Abone Ol', 'merkez-finans' ); ?>">
								<i class="fas fa-arrow-right"></i>
							</button>
						</div>
						<div class="newsletter-message" id="newsletter-message" style="display:none;"></div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer Bottom Bar -->
	<div class="footer-bottom">
		<div class="container footer-bottom-inner">
			<p class="copyright">
				&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'Tüm hakları saklıdır.', 'merkez-finans' ); ?>
			</p>
			<nav class="footer-legal" aria-label="<?php esc_attr_e( 'Yasal Sayfalar', 'merkez-finans' ); ?>">
				<a href="#"><?php esc_html_e( 'Gizlilik Politikası', 'merkez-finans' ); ?></a>
				<a href="#"><?php esc_html_e( 'KVKK', 'merkez-finans' ); ?></a>
				<a href="#"><?php esc_html_e( 'Çerez Politikası', 'merkez-finans' ); ?></a>
			</nav>
		</div>
	</div>
</footer>

<!-- WhatsApp Floating Button -->
<?php
$whatsapp_number = merkez_finans_get_contact( 'whatsapp' );
if ( ! empty( $whatsapp_number ) ) :
?>
<a
	href="https://wa.me/<?php echo esc_attr( $whatsapp_number ); ?>"
	target="_blank"
	rel="noopener noreferrer"
	class="whatsapp-float"
	aria-label="<?php esc_attr_e( 'WhatsApp ile iletişime geçin', 'merkez-finans' ); ?>"
>
	<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
</a>
<?php endif; ?>

<!-- Back to Top Button -->
<button
	type="button"
	class="back-to-top"
	id="back-to-top"
	aria-label="<?php esc_attr_e( 'Yukarı çık', 'merkez-finans' ); ?>"
	hidden
>
	<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="18 15 12 9 6 15"/></svg>
</button>

<?php wp_footer(); ?>

</body>
</html>
