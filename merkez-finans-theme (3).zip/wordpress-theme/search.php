<?php
/**
 * Search Results Template
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();
?>

<section class="page-header" style="background: var(--gradient-navy);">
	<div class="container">
		<h1 class="page-title">
			<?php
			printf(
				esc_html__( '"%s" için arama sonuçları', 'merkez-finans' ),
				esc_html( get_search_query() )
			);
			?>
		</h1>
	</div>
</section>

<div class="blog-layout section-padding">
	<div class="container">
		<div class="blog-grid has-sidebar">

			<div class="blog-main">
				<?php if ( have_posts() ) : ?>
					<div class="blog-posts-grid">
						<?php while ( have_posts() ) : the_post(); ?>
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-card' ); ?>>
								<?php if ( has_post_thumbnail() ) : ?>
									<div class="blog-card-image">
										<a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
											<?php the_post_thumbnail( 'medium_large', array( 'alt' => the_title_attribute( array( 'echo' => false ) ), 'loading' => 'lazy' ) ); ?>
										</a>
										<div class="blog-card-overlay"></div>
									</div>
								<?php endif; ?>
								<div class="blog-card-content">
									<h2 class="blog-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									<div class="blog-card-excerpt"><?php the_excerpt(); ?></div>
								</div>
							</article>
						<?php endwhile; ?>
					</div>
					<?php echo wp_kses_post( merkez_finans_pagination() ); ?>
				<?php else : ?>
					<div class="no-results">
						<h2><?php esc_html_e( 'Sonuç bulunamadı', 'merkez-finans' ); ?></h2>
						<p><?php esc_html_e( 'Farklı anahtar kelimelerle tekrar deneyin.', 'merkez-finans' ); ?></p>
					</div>
				<?php endif; ?>
			</div>

			<aside class="blog-sidebar" role="complementary">
				<div class="sidebar-widget">
					<h4 class="widget-title"><?php esc_html_e( 'Yeni Arama', 'merkez-finans' ); ?></h4>
					<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
						<label><input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Ara...', 'merkez-finans' ); ?>" value="<?php echo get_search_query(); ?>" name="s"></label>
						<button type="submit" class="search-submit" aria-label="<?php esc_attr_e( 'Ara', 'merkez-finans' ); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></button>
					</form>
				</div>
			</aside>

		</div>
	</div>
</div>

<?php get_footer(); ?>
