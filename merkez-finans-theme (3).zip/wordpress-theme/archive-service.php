<?php
/**
 * Service Archive Template
 *
 * Displays all services in a grid layout.
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();

$archive_title = get_theme_mod( 'merkez_finans_services_page_title', __( 'Hizmetlerimiz', 'merkez-finans' ) );
$archive_sub   = get_theme_mod( 'merkez_finans_services_page_subtitle', __( 'Isletmenize ozel kapsamli finansal cozumler.', 'merkez-finans' ) );
?>

<!-- ==================== PAGE HEADER ==================== -->
<section class="page-header" style="background: var(--gradient-navy);">
	<div class="container">
		<h1 class="page-title"><?php echo esc_html( $archive_title ); ?></h1>
		<?php if ( $archive_sub ) : ?>
			<p class="page-subtitle" style="color: rgba(255,255,255,0.8); font-size: var(--text-lg); margin-top: 12px;">
				<?php echo esc_html( $archive_sub ); ?>
			</p>
		<?php endif; ?>
		<?php echo wp_kses_post( merkez_finans_breadcrumbs() ); ?>
	</div>
</section>

<!-- ==================== SERVICES LISTING ==================== -->
<section class="services-archive section-padding">
	<div class="container">
		<?php if ( have_posts() ) : ?>

			<div class="services-archive-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					$icon = get_post_meta( get_the_ID(), '_service_icon_svg', true );
					if ( empty( $icon ) ) {
						// Varsayilan ikon
						$icon = '<i class="fas fa-circle-notch"></i>';
					}
				?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'service-archive-card' ); ?>>
						<div class="service-archive-icon">
							<?php echo wp_kses_post( $icon ); ?>
						</div>
						<div class="service-archive-content">
							<h2 class="service-archive-title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>
							<div class="service-archive-excerpt">
								<?php the_excerpt(); ?>
							</div>
							<?php
							$features = get_post_meta( get_the_ID(), '_service_features', true );
							if ( ! empty( $features ) && is_array( $features ) ) :
							?>
								<ul class="service-archive-features">
									<?php foreach ( array_slice( $features, 0, 4 ) as $feature ) : ?>
										<li>
											<i class="fas fa-check"></i>
											<?php echo esc_html( $feature ); ?>
										</li>
									<?php endforeach; ?>
								</ul>
								<?php endif; ?>
							<a href="<?php the_permalink(); ?>" class="service-archive-link">
								<?php esc_html_e( 'Detayli Bilgi', 'merkez-finans' ); ?>
								<i class="fas fa-arrow-right" aria-hidden="true"></i>
							</a>
						</div>
					</article>
				<?php endwhile; ?>
			</div>

			<!-- Pagination -->
			<?php echo wp_kses_post( merkez_finans_pagination() ); ?>

		<?php else : ?>

			<div class="no-results">
				<div class="no-results-icon">
					<i class="fas fa-folder-open" style="font-size:48px;" aria-hidden="true"></i>
				</div>
				<h2><?php esc_html_e( 'Henüz hizmet bulunmuyor.', 'merkez-finans' ); ?></h2>
				<p><?php esc_html_e( 'Yakinda yeni hizmetler ekleyecegiz.', 'merkez-finans' ); ?></p>
			</div>

		<?php endif; ?>
	</div>
</section>

<?php
get_footer();
