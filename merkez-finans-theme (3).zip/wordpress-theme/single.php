<?php
/**
 * Single Post Template
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();

while ( have_posts() ) :
	the_post();
?>

<!-- Page Header -->
<section class="page-header" style="background: var(--gradient-navy);">
	<div class="container">
		<?php
		$category = get_the_category();
		if ( ! empty( $category ) ) :
		?>
			<span class="section-badge" style="background: rgba(255,255,255,0.15); color: #fff; border: 1px solid rgba(255,255,255,0.25);">
				<?php echo esc_html( $category[0]->name ); ?>
			</span>
		<?php endif; ?>
		<h1 class="page-title"><?php the_title(); ?></h1>
		<div class="blog-preview-meta" style="justify-content: center; color: rgba(255,255,255,0.7); margin-top: 16px;">
			<span>
				<i class="far fa-calendar"></i>
				<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
			</span>
			<span>
				<i class="far fa-clock"></i>
				<?php echo esc_html( merkez_finans_reading_time() ); ?>
			</span>
		</div>
	</div>
</section>

<!-- Article Content -->
<article class="section-padding" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="container" style="max-width: 800px;">

		<?php if ( has_post_thumbnail() ) : ?>
			<div class="blog-featured-image" style="margin-bottom: 48px; border-radius: 24px; overflow: hidden;">
				<?php the_post_thumbnail( 'large', array( 'alt' => the_title_attribute( array( 'echo' => false ) ), 'style' => 'width: 100%; height: auto;' ) ); ?>
			</div>
		<?php endif; ?>

		<div class="entry-content" style="font-size: var(--text-lg); line-height: 1.8; color: var(--color-text-dark);">
			<?php the_content(); ?>
		</div>

		<!-- Social Share -->
		<div class="social-share-wrap">
			<?php echo wp_kses_post( merkez_finans_social_share() ); ?>
		</div>

		<!-- Related Posts -->
		<?php
		$related = new WP_Query( array(
			'category__in'   => wp_get_post_categories( get_the_ID() ),
			'post__not_in'   => array( get_the_ID() ),
			'posts_per_page' => 3,
		) );

		if ( $related->have_posts() ) :
		?>
		<div style="margin-top: 64px;">
			<h3 style="font-size: var(--text-2xl); margin-bottom: 32px;"><?php esc_html_e( 'İlgili Yazılar', 'merkez-finans' ); ?></h3>
			<div class="blog-preview-grid">
				<?php while ( $related->have_posts() ) : $related->the_post(); ?>
					<article class="blog-preview-card">
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="blog-preview-image" style="height: 160px;">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium', array( 'style' => 'width: 100%; height: 100%; object-fit: cover;' ) ); ?></a>
							</div>
						<?php endif; ?>
						<div class="blog-preview-content" style="padding: 20px;">
							<h4 style="font-size: var(--text-base); font-weight: 700;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
		</div>
		<?php wp_reset_postdata(); endif; ?>

		<!-- Comments -->
		<?php if ( comments_open() || get_comments_number() ) : ?>
		<div class="comments-area" style="margin-top: 64px;">
			<?php comments_template(); ?>
		</div>
		<?php endif; ?>

	</div>
</article>

<?php
endwhile;
get_footer();
