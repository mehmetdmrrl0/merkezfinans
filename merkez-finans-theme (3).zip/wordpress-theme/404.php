<?php
/**
 * 404 Error Page Template
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();
?>

<section class="section-padding" style="text-align: center; min-height: 60vh; display: flex; align-items: center;">
	<div class="container" style="max-width: 600px;">

		<div style="display: inline-flex; width: 120px; height: 120px; border-radius: 50%; background: var(--color-soft); align-items: center; justify-content: center; margin-bottom: 32px;">
			<span style="font-family: var(--font-heading); font-size: 4.8rem; font-weight: 800; color: var(--color-accent);">404</span>
		</div>

		<h1 style="font-size: var(--text-3xl); margin-bottom: 16px;"><?php esc_html_e( 'Sayfa Bulunamadı', 'merkez-finans' ); ?></h1>
		<p style="font-size: var(--text-lg); color: var(--color-text-muted); line-height: 1.7; margin-bottom: 32px;">
			<?php esc_html_e( 'Aradığınız sayfa mevcut değil veya taşınmış olabilir. Aşağıdaki bağlantıları kullanarak istediğiniz içeriğe ulaşabilirsiniz.', 'merkez-finans' ); ?>
		</p>

		<div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; margin-bottom: 48px;">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary">
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
				<?php esc_html_e( 'Ana Sayfaya Dön', 'merkez-finans' ); ?>
			</a>
			<a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="btn btn-outline">
				<?php esc_html_e( 'Blog Yazıları', 'merkez-finans' ); ?>
			</a>
		</div>

		<div style="background: var(--color-soft); border-radius: 24px; padding: 32px;">
			<h3 style="font-size: var(--text-lg); margin-bottom: 16px;"><?php esc_html_e( 'Bir şey mi arıyorsunuz?', 'merkez-finans' ); ?></h3>
			<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="max-width: 400px; margin: 0 auto;">
				<div style="display: flex; gap: 0;">
					<label style="flex: 1;"><input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Anahtar kelime...', 'merkez-finans' ); ?>" value="<?php echo get_search_query(); ?>" name="s" style="border-radius: 16px 0 0 16px;"></label>
					<button type="submit" class="search-submit" aria-label="<?php esc_attr_e( 'Ara', 'merkez-finans' ); ?>" style="border-radius: 0 16px 16px 0;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></button>
				</div>
			</form>
		</div>

	</div>
</section>

<?php get_footer(); ?>
