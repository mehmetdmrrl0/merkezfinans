<?php
/**
 * Blog Home Template
 *
 * Displays all blog posts when a "Posts page" is set in Settings > Reading.
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();
?>

<!-- ==================== PAGE HEADER ==================== -->
<section class="page-header" style="background: var(--gradient-navy);">
	<div class="container">
		<h1 class="page-title">
			<?php echo esc_html( get_theme_mod( 'merkez_finans_blog_page_title', __( 'Blog & Bilgilendirme', 'merkez-finans' ) ) ); ?>
		</h1>
		<p class="page-subtitle" style="color: rgba(255,255,255,0.8); font-size: var(--text-lg); margin-top: 12px;">
			<?php echo esc_html( get_theme_mod( 'merkez_finans_blog_page_subtitle', __( 'Finansal danismanlik, vergi mevzuati ve is dunyasindan guncel icerikler.', 'merkez-finans' ) ) ); ?>
		</p>
		<?php echo wp_kses_post( merkez_finans_breadcrumbs() ); ?>
	</div>
</section>

<!-- ==================== BLOG LISTING ==================== -->
<div class="blog-layout section-padding">
	<div class="container">
		<div class="blog-grid has-sidebar">

			<!-- Main Content Column -->
			<div class="blog-main">
				<?php if ( have_posts() ) : ?>

					<div class="blog-posts-grid">
						<?php
						while ( have_posts() ) :
							the_post();
							$category = get_the_category();
						?>
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-card' ); ?>>

								<?php if ( has_post_thumbnail() ) : ?>
									<div class="blog-card-image">
										<a href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
											<?php
											the_post_thumbnail(
												'merkez-finans-blog',
												array(
													'alt' => the_title_attribute( array( 'echo' => false ) ),
													'loading' => 'lazy',
												)
											);
											?>
										</a>
										<div class="blog-card-overlay"></div>
										<?php if ( ! empty( $category ) ) : ?>
											<span class="blog-card-category">
												<?php echo esc_html( $category[0]->name ); ?>
											</span>
										<?php endif; ?>
									</div>
								<?php endif; ?>

								<div class="blog-card-content">
									<div class="blog-card-meta">
										<span class="meta-date">
											<i class="far fa-calendar" aria-hidden="true"></i>
											<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>">
												<?php echo esc_html( get_the_date() ); ?>
											</time>
										</span>
										<span class="meta-reading-time">
											<i class="far fa-clock" aria-hidden="true"></i>
											<?php echo esc_html( merkez_finans_reading_time() ); ?>
										</span>
									</div>

									<h2 class="blog-card-title">
										<a href="<?php the_permalink(); ?>">
											<?php the_title(); ?>
										</a>
									</h2>

									<div class="blog-card-excerpt">
										<?php the_excerpt(); ?>
									</div>

									<a href="<?php the_permalink(); ?>" class="blog-card-read-more">
										<?php esc_html_e( 'Devamini Oku', 'merkez-finans' ); ?>
										<i class="fas fa-arrow-right" aria-hidden="true"></i>
									</a>
								</div>
							</article>
						<?php endwhile; ?>
					</div>

					<!-- Pagination -->
					<?php echo wp_kses_post( merkez_finans_pagination() ); ?>

				<?php else : ?>

					<div class="no-results">
						<div class="no-results-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
						</div>
						<h2><?php esc_html_e( 'Henüz blog yazisi bulunmuyor.', 'merkez-finans' ); ?></h2>
						<p><?php esc_html_e( 'Yakinda yeni icerikler ekleyecegiz.', 'merkez-finans' ); ?></p>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary" style="margin-top: 24px;">
							<?php esc_html_e( 'Anasayfaya Don', 'merkez-finans' ); ?>
						</a>
					</div>

				<?php endif; ?>
			</div>

			<!-- Sidebar Column -->
			<aside class="blog-sidebar" role="complementary">
				<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
					<?php dynamic_sidebar( 'sidebar-1' ); ?>
				<?php else : ?>
					<div class="sidebar-widget">
						<h4 class="widget-title"><?php esc_html_e( 'Arama', 'merkez-finans' ); ?></h4>
						<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
							<label>
								<span class="screen-reader-text"><?php esc_html_e( 'Ara:', 'merkez-finans' ); ?></span>
								<input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Ara...', 'merkez-finans' ); ?>" value="<?php echo get_search_query(); ?>" name="s">
							</label>
							<button type="submit" class="search-submit" aria-label="<?php esc_attr_e( 'Ara', 'merkez-finans' ); ?>">
								<i class="fas fa-search" aria-hidden="true"></i>
							</button>
						</form>
					</div>

					<div class="sidebar-widget">
						<h4 class="widget-title"><?php esc_html_e( 'Kategoriler', 'merkez-finans' ); ?></h4>
						<ul class="widget-category-list">
							<?php
							wp_list_categories(
								array(
									'title_li'   => '',
									'show_count' => true,
								)
							);
							?>
						</ul>
					</div>

					<div class="sidebar-widget">
						<h4 class="widget-title"><?php esc_html_e( 'Son Yazilar', 'merkez-finans' ); ?></h4>
						<ul class="widget-recent-posts">
						<?php
							$recent = new WP_Query( array( 'posts_per_page' => 5 ) );
							while ( $recent->have_posts() ) : $recent->the_post();
							?>
								<li>
									<a href="<?php the_permalink(); ?>">
										<?php if ( has_post_thumbnail() ) : ?>
											<?php the_post_thumbnail( 'thumbnail', array( 'style' => 'width: 48px; height: 48px; object-fit: cover; border-radius: 8px; float: left; margin-right: 12px;' ) ); ?>
										<?php endif; ?>
										<span style="font-weight: 600; font-size: var(--text-sm);"><?php the_title(); ?></span>
										<span style="display: block; font-size: var(--text-xs); color: var(--color-text-muted); margin-top: 4px;"><?php echo esc_html( get_the_date() ); ?></span>
									</a>
								</li>
							<?php endwhile; wp_reset_postdata(); ?>
						</ul>
					</div>
				<?php endif; ?>
			</aside>

		</div>
</div>
</div>

<?php
get_footer();
