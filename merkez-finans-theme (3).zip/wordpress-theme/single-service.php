<?php
/**
 * Single Service Template
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();

while ( have_posts() ) :
	the_post();

	$icon     = get_post_meta( get_the_ID(), '_service_icon_svg', true );
	$features = get_post_meta( get_the_ID(), '_service_features', true );
	$process  = get_post_meta( get_the_ID(), '_service_process', true );

	if ( empty( $icon ) ) {
		$icon = '<i class="fas fa-circle-notch fa-2x"></i>';
	}
?>

<!-- Page Header -->
<section class="page-header" style="background: var(--gradient-navy);">
	<div class="container">
		<div class="service-detail-header">
			<div class="service-detail-icon">
				<?php echo wp_kses_post( $icon ); ?>
			</div>
			<h1 class="page-title"><?php the_title(); ?></h1>
		</div>
		<?php echo wp_kses_post( merkez_finans_breadcrumbs() ); ?>
	</div>
</section>

<!-- Service Content -->
<article class="section-padding" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="container">
		<div class="service-detail-grid">

			<!-- Main Content -->
			<div class="service-detail-main">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="service-detail-image">
						<?php the_post_thumbnail( 'large', array( 'alt' => the_title_attribute( array( 'echo' => false ) ) ) ); ?>
					</div>
				<?php endif; ?>

				<div class="entry-content service-detail-content">
					<?php the_content(); ?>
				</div>

				<?php if ( ! empty( $features ) && is_array( $features ) ) : ?>
					<div class="service-detail-features">
						<h3><?php esc_html_e( 'Hizmet Kapsami', 'merkez-finans' ); ?></h3>
						<ul>
							<?php foreach ( $features as $feature ) : ?>
								<li>
									<i class="fas fa-check"></i>
									<?php echo esc_html( $feature ); ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $process ) && is_array( $process ) ) : ?>
					<div class="service-detail-process">
						<h3><?php esc_html_e( 'Calisma Sureci', 'merkez-finans' ); ?></h3>
						<div class="service-process-steps">
							<?php foreach ( $process as $index => $step ) : ?>
								<div class="service-process-step">
									<span class="service-process-number"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
									<p><?php echo esc_html( $step ); ?></p>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>

			<!-- Sidebar -->
			<aside class="service-detail-sidebar">
				<div class="service-cta-card">
					<h4><?php esc_html_e( 'Bu Hizmet Hakkinda Bilgi Alin', 'merkez-finans' ); ?></h4>
					<p><?php esc_html_e( 'Uzman ekibimizden bu hizmet ile ilgili detayli bilgi ve teklif almak icin iletisime gecin.', 'merkez-finans' ); ?></p>
					<a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" class="btn btn-primary" style="width: 100%; justify-content: center;">
						<?php esc_html_e( 'Ucretsiz Danismanlik Al', 'merkez-finans' ); ?>
						<i class="fas fa-arrow-right"></i>
					</a>
					<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', merkez_finans_get_contact( 'phone' ) ) ); ?>" class="btn btn-outline" style="width: 100%; justify-content: center; margin-top: 12px;">
						<i class="fas fa-phone"></i>
						<?php echo esc_html( merkez_finans_get_contact( 'phone' ) ); ?>
					</a>
				</div>

				<div class="service-contact-info">
					<h4><?php esc_html_e( 'Iletisim', 'merkez-finans' ); ?></h4>
					<div class="service-contact-item">
						<i class="fas fa-envelope"></i>
						<a href="mailto:<?php echo esc_attr( merkez_finans_get_contact( 'email' ) ); ?>"><?php echo esc_html( merkez_finans_get_contact( 'email' ) ); ?></a>
					</div>
					<div class="service-contact-item">
						<i class="fas fa-clock"></i>
						<span><?php echo esc_html( merkez_finans_get_contact( 'working_hours' ) ); ?></span>
					</div>
				</div>
			</aside>

		</div>
	</div>
</article>

<!-- Related Services -->
<?php
$related = new WP_Query(
	array(
		'post_type'      => 'service',
		'posts_per_page' => 3,
		'post__not_in'   => array( get_the_ID() ),
		'orderby'        => 'rand',
	)
);

if ( $related->have_posts() ) :
?>
<section class="related-services section-padding" style="background: var(--color-soft);">
	<div class="container">
		<h2 class="section-title" style="text-align: center; margin-bottom: 48px;"><?php esc_html_e( 'Diger Hizmetlerimiz', 'merkez-finans' ); ?></h2>
		<div class="services-archive-grid" style="grid-template-columns: repeat(3, 1fr);">
			<?php
			while ( $related->have_posts() ) :
				$related->the_post();
				$r_icon = get_post_meta( get_the_ID(), '_service_icon_svg', true );
				if ( empty( $r_icon ) ) {
					$r_icon = '<i class="fas fa-circle-notch"></i>';
				}
			?>
				<article class="service-archive-card">
					<div class="service-archive-icon">
						<?php echo wp_kses_post( $r_icon ); ?>
					</div>
					<h3 class="service-archive-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					<div class="service-archive-excerpt"><?php the_excerpt(); ?></div>
					<a href="<?php the_permalink(); ?>" class="service-archive-link">
						<?php esc_html_e( 'Incele', 'merkez-finans' ); ?>
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
					</a>
				</article>
			<?php endwhile; ?>
		</div>
	</div>
</section>
<?php wp_reset_postdata(); endif; ?>

<?php
endwhile;
get_footer();
