<?php
/**
 * Theme Header Template
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="theme-color" content="#071B3A">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<!-- Font Awesome 6 Free -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Skip to content link for accessibility -->
<a class="skip-link" href="#primary-content"><?php esc_html_e( 'Ana içeriğe geç', 'merkez-finans' ); ?></a>

<!-- ==================== HEADER ==================== -->
<header class="site-header" id="site-header" role="banner">
	<div class="container header-inner">

		<!-- Logo -->
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<div class="site-logo">
					<?php the_custom_logo(); ?>
				</div>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo-link" rel="home">
					<div class="logo-box">
						<span class="logo-letter">M</span>
					</div>
					<div class="logo-text">
						<span class="logo-title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
						<span class="logo-tagline"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></span>
					</div>
				</a>
			<?php endif; ?>
		</div>

		<!-- Desktop Navigation -->
		<nav class="main-navigation" id="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Ana Menü', 'merkez-finans' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location'  => 'primary',
					'menu_id'         => 'primary-menu',
					'menu_class'      => 'nav-menu',
					'container'       => false,
					'fallback_cb'     => false,
					'depth'           => 2,
					'walker'          => new Merkez_Finans_Nav_Walker(),
				)
			);
			?>
		</nav>

		<!-- Header CTA + Phone -->
		<div class="header-actions">
			<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', merkez_finans_get_contact( 'phone' ) ) ); ?>" class="header-phone hide-mobile">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
				<span><?php echo esc_html( merkez_finans_get_contact( 'phone' ) ); ?></span>
			</a>
			<a href="#contact" class="btn btn-primary header-cta">
				<?php esc_html_e( 'Ücretsiz Ön Görüşme Al', 'merkez-finans' ); ?>
			</a>
		</div>

		<!-- Mobile Menu Toggle -->
		<button
			type="button"
			class="mobile-menu-toggle"
			id="mobile-menu-toggle"
			aria-controls="mobile-navigation"
			aria-expanded="false"
			aria-label="<?php esc_attr_e( 'Menüyü Aç/Kapat', 'merkez-finans' ); ?>"
		>
			<span class="hamburger-line" aria-hidden="true"></span>
			<span class="hamburger-line" aria-hidden="true"></span>
			<span class="hamburger-line" aria-hidden="true"></span>
		</button>
	</div>

	<!-- Mobile Navigation Overlay -->
	<div class="mobile-navigation" id="mobile-navigation" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Mobil Menü', 'merkez-finans' ); ?>" hidden>
		<div class="mobile-nav-inner">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_id'        => 'mobile-menu',
					'menu_class'     => 'mobile-nav-menu',
					'container'      => false,
					'fallback_cb'    => false,
					'depth'          => 2,
				)
			);
			?>
			<div class="mobile-nav-footer">
				<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', merkez_finans_get_contact( 'phone' ) ) ); ?>" class="mobile-nav-phone">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
					<span><?php echo esc_html( merkez_finans_get_contact( 'phone' ) ); ?></span>
				</a>
				<a href="#contact" class="btn btn-primary mobile-nav-cta">
					<?php esc_html_e( 'Ücretsiz Ön Görüşme Al', 'merkez-finans' ); ?>
				</a>
			</div>
		</div>
	</div>

	<!-- Scroll progress bar -->
	<div class="scroll-progress" id="scroll-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="<?php esc_attr_e( 'Sayfa kaydırma ilerlemesi', 'merkez-finans' ); ?>"></div>
</header>

<!-- Main Content Start -->
<main id="primary-content" class="site-main" role="main">
