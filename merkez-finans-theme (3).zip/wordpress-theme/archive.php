<?php
/**
 * Archive Template (Category, Tag, Date, Author)
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();
?>

<!-- Page Header -->
<section class="page-header" style="background: var(--gradient-navy);">
	<div class="container">
		<h1 class="page-title"><?php the_archive_title(); ?></h1>
		<?php if ( get_the_archive_description() ) : ?>
			<p style="color: rgba(255,255,255,0.7); margin-top: 8px;"><?php echo wp_kses_post( get_the_archive_description() ); ?></p>
		<?php endif; ?>
		<?php echo wp_kses_post( merkez_finans_breadcrumbs() ); ?>
	</div>
</section>

<!-- Archive Posts -->
<div class="blog-layout section-padding">
	<div class="container">
		<div class="blog-grid has-sidebar">

			<div class="blog-main">
				<?php if ( have_posts() ) : ?>
					<div class="blog-posts-grid">
						<?php while ( have_posts() ) : the_post(); ?>
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-card' ); ?>>
								<?php if ( has_post_thumbnail() ) : ?>
									<div class="blog-card-image">
										<a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
											<?php the_post_thumbnail( 'medium_large', array( 'alt' => the_title_attribute( array( 'echo' => false ) ), 'loading' => 'lazy' ) ); ?>
										</a>
										<div class="blog-card-overlay"></div>
									</div>
								<?php endif; ?>
								<div class="blog-card-content">
									<div class="blog-card-meta">
										<span><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg> <time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></span>
										<span><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> <?php echo esc_html( merkez_finans_reading_time() ); ?></span>
									</div>
									<h2 class="blog-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									<div class="blog-card-excerpt"><?php the_excerpt(); ?></div>
								</div>
							</article>
						<?php endwhile; ?>
					</div>
					<?php echo wp_kses_post( merkez_finans_pagination() ); ?>
				<?php else : ?>
					<div class="no-results">
						<p><?php esc_html_e( 'Bu kategoride henüz içerik bulunmuyor.', 'merkez-finans' ); ?></p>
					</div>
				<?php endif; ?>
			</div>

			<aside class="blog-sidebar" role="complementary">
				<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
					<?php dynamic_sidebar( 'sidebar-1' ); ?>
				<?php else : ?>
					<div class="sidebar-widget">
						<h4 class="widget-title"><?php esc_html_e( 'Arama', 'merkez-finans' ); ?></h4>
						<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
							<label><span class="screen-reader-text"><?php esc_html_e( 'Ara:', 'merkez-finans' ); ?></span><input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Ara...', 'merkez-finans' ); ?>" value="<?php echo get_search_query(); ?>" name="s"></label>
							<button type="submit" class="search-submit" aria-label="<?php esc_attr_e( 'Ara', 'merkez-finans' ); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></button>
						</form>
					</div>
				<?php endif; ?>
			</aside>

		</div>
	</div>
</div>

<?php get_footer(); ?>
