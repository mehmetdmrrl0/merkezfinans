=== Merkez Finansal Danismanlik ===
Contributors: merkezfinans
Requires at least: 6.4
Tested up to: 6.5
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: corporate, finance, consulting, responsive, custom-colors, custom-logo, custom-menu, editor-style, featured-images, theme-options, threaded-comments, translation-ready, wide-blocks, block-styles

Premium kurumsal finans, vergi danismanligi ve mali musavirlik WordPress temasi.

== Description ==

Merkez Finansal Danismanlik temasi; vergi, muhasebe, denetim ve finansal danismanlik firmalari icin tasarlanmis, modern, hizli ve donusum odakli bir WordPress temasidir.

= Ozellikler =

* **9 Bolumlu Ana Sayfa:** Hero video, hizmetler, neden biz, calisma modeli, sektorler, istatistikler, CTA, blog, iletisim
* **Elementor Uyumlu:** Full width, canvas ve landing page sablonlari
* **Gutenberg Destegi:** Block editor ile tam uyumlu, theme.json destegi
* **Customizer:** Renkler, iletisim bilgileri, sosyal medya ayarlari
* **Hizmetler CPT:** Ozel hizmet icerik turu
* **Guvenlik:** Escape/sanitize, nonce, guvenlik basliklari
* **Performans:** Emoji temizligi, lazy load, minimal JS/CSS
* **Erisilebilirlik:** Skip link, focus-visible, ARIA etiketleri, reduced motion
* **Responsive:** Mobil, tablet, masaustu optimizasyonu

= Renk Paleti =

* Navy: #071B3A
* Mavi: #0E4D92
* Accent: #2EA8FF
* Soft Blue: #EEF7FF
* Text Dark: #101828
* Text Muted: #667085

= Fontlar =

* Baslik: Manrope (Google Fonts)
* Govde: Inter (Google Fonts)

== Installation ==

1. Temayi WordPress admin panelinden yukleyin: Gorunum > Temalar > Yeni Ekle > Tema Yukle
2. Zip dosyasini secin ve "Simdi Kur" dugmesine tiklayin
3. Kurulum tamamlandiktan sonra "Etkinlestir" dugmesine tiklayin

== Changelog ==

= 1.0.0 =
* Initial release
