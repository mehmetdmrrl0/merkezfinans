<?php
/**
 * Template Name: Tam Genişlik (Elementor Uyumlu)
 * Template Post Type: page
 *
 * Full width page without sidebar. Compatible with Elementor.
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();
?>

<?php if ( ! has_action( 'elementor/loaded' ) || ! \Elementor\Plugin::$instance->preview->is_preview_mode() ) : ?>
<section class="page-header" style="background: var(--gradient-navy);">
	<div class="container">
		<h1 class="page-title"><?php the_title(); ?></h1>
		<?php echo wp_kses_post( merkez_finans_breadcrumbs() ); ?>
	</div>
</section>
<?php endif; ?>

<section class="section-padding">
	<div class="container">
		<?php
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
		?>
	</div>
</section>

<?php get_footer(); ?>
