<?php
/**
 * Template Name: Elementor Tuval (Canvas)
 * Template Post Type: page
 *
 * Blank canvas template for Elementor full control.
 * No header, no footer - Elementor handles everything.
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

wp_head();
?>

<body <?php body_class( 'elementor-canvas' ); ?>>
<?php wp_body_open(); ?>

<?php
while ( have_posts() ) :
	the_post();
	the_content();
endwhile;
?>

<?php wp_footer(); ?>
</body>
</html>
