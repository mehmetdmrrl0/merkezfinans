<?php
/**
 * Template Name: Landing Page (Reklam Odaklı)
 * Template Post Type: page
 *
 * Optimized for Google Ads / Meta conversion.
 * Sticky CTA bar, minimal distractions.
 *
 * @package Merkez_Finans
 * @version 1.0.0
 */

declare( strict_types=1 );

get_header();
?>

<!-- Sticky Landing CTA Bar -->
<div class="landing-sticky-bar" id="landing-sticky-bar" style="position: fixed; bottom: 0; left: 0; right: 0; z-index: 999; background: var(--color-navy); padding: 12px 0; transform: translateY(100%); transition: transform 0.3s ease;">
	<div class="container" style="display: flex; align-items: center; justify-content: space-between; gap: 16px;">
		<div class="hide-mobile">
			<span style="color: #fff; font-size: var(--text-sm); font-weight: 600;"><?php esc_html_e( 'Ücretsiz danışmanlık almak için hemen arayın', 'merkez-finans' ); ?></span>
		</div>
		<div style="display: flex; gap: 12px;">
			<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', merkez_finans_get_contact( 'phone' ) ) ); ?>" class="btn btn-secondary" style="font-size: var(--text-sm); padding: 10px 20px;">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
				<?php echo esc_html( merkez_finans_get_contact( 'phone' ) ); ?>
			</a>
			<a href="#contact" class="btn btn-primary" style="font-size: var(--text-sm); padding: 10px 20px;"><?php esc_html_e( 'Form Doldur', 'merkez-finans' ); ?></a>
		</div>
	</div>
</div>

<!-- Main Content -->
<section class="section-padding" style="padding-bottom: 100px;">
	<div class="container">
		<?php
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
		?>
	</div>
</section>

<script>
(function() {
	var bar = document.getElementById('landing-sticky-bar');
	if (!bar) return;
	window.addEventListener('scroll', function() {
		if (window.scrollY > 400) {
			bar.style.transform = 'translateY(0)';
		} else {
			bar.style.transform = 'translateY(100%)';
		}
	});
})();
</script>

<?php get_footer(); ?>
